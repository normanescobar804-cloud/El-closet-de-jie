export interface Product {
  id: string;
  name: string;
  price: number; // in Cordobas (C$)
  originalPrice?: number;
  category: string;
  condition?: 'nueva' | 'usada'; // Ropa Nueva o Ropa Usada
  description: string;
  icon?: string;
  images: string[];
  sizes: string[];
  colors: string[];
  inStock: boolean;
  featured?: boolean;
  rating?: number; // Calificación promedio de 1 a 5 estrellas
  reviewCount?: number; // Cantidad total de calificaciones
  createdAt: number;
}

export interface ProductReview {
  id: string;
  productId: string;
  customerName: string;
  rating: number; // 1 a 5 estrellas
  comment?: string;
  verifiedPurchase?: boolean;
  createdAt: string;
}

export interface CartItem {
  id: string; // unique item id based on product.id + size + color
  product: Product;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export type CurrencyType = 'cordobas' | 'dolares';

export type DeliveryMethod = 'indrive' | 'departamental' | 'pickup';

export interface StoreSettings {
  storeName: string;
  tagline: string;
  whatsappNumber: string; // e.g. "50583702337"
  whatsappCustomGreeting: string;
  currencySymbol: string;
  currencyCode: string;
  exchangeRate: number; // e.g. 36.5 NIO per USD
  discountPercent: number; // e.g. 20%
  shippingCost: number;
  freeShippingThreshold: number;
  adminPin: string;
  instagramUrl?: string;
  facebookUrl?: string;
  tiktokUrl?: string;
  address?: string;
  bankAccount?: string;
  bankAccountHolder?: string;
  // inDrive Configuration
  indriveEnabled: boolean;
  indriveEstimatedCost: number; // e.g. 70
  indrivePickupAddress: string;
}

export interface UserAccount {
  name: string;
  phoneOrEmail: string;
  city?: string;
  address?: string;
  isLoggedIn: boolean;
  loginDate?: string;
}

export interface OrderItemRecord {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  size?: string;
  color?: string;
}

export interface OrderRecord {
  id: string;
  createdAt: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  customerCity?: string;
  notes?: string;
  deliveryMethod?: DeliveryMethod;
  indriveReference?: string;
  indriveLocationUrl?: string;
  items: OrderItemRecord[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  currency: CurrencyType;
  status: 'pendiente' | 'en_preparacion' | 'enviado' | 'entregado';
}

export interface CustomerInquiry {
  id: string;
  createdAt: string;
  customerName: string;
  customerPhone: string;
  customerCity?: string;
  inquiryType: 'prenda' | 'talla_stock' | 'envio_indrive' | 'inscripcion_ofertas' | 'consulta_general';
  productName?: string;
  message: string;
  status: 'nuevo' | 'respondido' | 'archivado';
}

export type CategoryFilter = 
  | 'Todas'
  | 'Camisetas y Camisas'
  | 'Pantalones y Jeans'
  | 'Vestidos y Faldas'
  | 'Chaquetas y Abrigos'
  | 'Ropa para Niños'
  | 'Bolsas y Accesorios'
  | 'Deportiva y Playa';

export interface PriceRangeFilter {
  id: string;
  label: string;
  min: number;
  max: number | null;
}
