import React, { useState, useEffect, useMemo } from 'react';
import {
  Sparkles,
  ShoppingBag,
  Heart,
  MessageCircle,
  Truck,
  ShieldCheck,
  CheckCircle2,
  SlidersHorizontal,
  ChevronRight,
  ArrowUpRight,
  Filter,
  ArrowUpDown
} from 'lucide-react';
import {
  CartItem,
  CategoryFilter,
  CurrencyType,
  OrderRecord,
  Product,
  StoreSettings,
  UserAccount
} from './types';
import {
  getSavedCart,
  getSavedFavorites,
  getSavedOrders,
  getSavedProducts,
  getSavedSettings,
  getSavedUser,
  getSavedCurrency,
  saveCart,
  saveFavorites,
  saveProducts,
  saveSettings,
  saveUser,
  saveCurrency,
  resetProductsToDefault,
  formatCurrency
} from './utils/storage';
import { PRODUCT_CATEGORIES } from './data/initialProducts';
import { Header } from './components/Header';
import { MobileNav } from './components/MobileNav';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { QuickAuthModal } from './components/QuickAuthModal';
import { FavoritesDrawer } from './components/FavoritesDrawer';
import { AdminModal } from './components/AdminModal';
import { ContactModal } from './components/ContactModal';
import { ToastContainer, ToastMessage } from './components/Toast';

type PriceRangeType = 'all' | '10-50' | '50-100' | '100-200' | '200-500' | '500+';
type SortOrderType = 'featured' | 'price-asc' | 'price-desc' | 'name-asc';

export default function App() {
  // --- Persistent States ---
  const [products, setProducts] = useState<Product[]>(getSavedProducts);
  const [cart, setCart] = useState<CartItem[]>(getSavedCart);
  const [storeSettings, setStoreSettings] = useState<StoreSettings>(getSavedSettings);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(getSavedUser);
  const [favorites, setFavorites] = useState<string[]>(getSavedFavorites);
  const [orders, setOrders] = useState<OrderRecord[]>(getSavedOrders);
  const [currency, setCurrency] = useState<CurrencyType>(getSavedCurrency);

  // --- Modal & Drawer Visibility States ---
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [contactProduct, setContactProduct] = useState<Product | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // --- Filtering & Search States ---
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>('Todas');
  const [searchQuery, setSearchQuery] = useState('');
  const [showOnlyInStock, setShowOnlyInStock] = useState(false);
  const [conditionFilter, setConditionFilter] = useState<'all' | 'nueva' | 'usada'>('all');
  const [priceRange, setPriceRange] = useState<PriceRangeType>('all');
  const [sortOrder, setSortOrder] = useState<SortOrderType>('featured');

  // --- Toast Notifications State ---
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (type: 'cart' | 'favorite' | 'info', title: string, subtitle?: string) => {
    const newToast: ToastMessage = {
      id: `toast-${Date.now()}-${Math.random()}`,
      type,
      title,
      subtitle
    };
    setToasts((prev) => [...prev.slice(-3), newToast]);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // --- 💾 Persistence Effects ---
  useEffect(() => {
    saveCart(cart);
  }, [cart]);

  useEffect(() => {
    saveProducts(products);
  }, [products]);

  useEffect(() => {
    saveSettings(storeSettings);
  }, [storeSettings]);

  useEffect(() => {
    saveUser(currentUser);
  }, [currentUser]);

  useEffect(() => {
    saveFavorites(favorites);
  }, [favorites]);

  useEffect(() => {
    saveCurrency(currency);
  }, [currency]);

  // --- 🛍️ Cart Actions ---
  const handleAddToCart = (product: Product, size?: string, color?: string, quantity: number = 1) => {
    const chosenSize = size || product.sizes?.[0] || 'Única';
    const chosenColor = color || product.colors?.[0] || 'Original';
    const itemId = `${product.id}-${chosenSize}-${chosenColor}`;

    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex((item) => item.id === itemId);
      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += quantity;
        return updated;
      } else {
        const newItem: CartItem = {
          id: itemId,
          product,
          quantity,
          selectedSize: chosenSize,
          selectedColor: chosenColor
        };
        return [...prevCart, newItem];
      }
    });

    addToast('cart', '¡Agregado al carrito!', `${quantity}x ${product.name} (${chosenSize})`);
  };

  const handleUpdateQuantity = (itemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveFromCart(itemId);
      return;
    }
    setCart((prevCart) =>
      prevCart.map((item) => (item.id === itemId ? { ...item, quantity: newQty } : item))
    );
  };

  const handleUpdateProductCartQuantity = (product: Product, newQty: number) => {
    const matchingItems = cart.filter((i) => i.product.id === product.id);
    if (matchingItems.length > 0) {
      if (newQty <= 0) {
        setCart((prev) => prev.filter((i) => i.product.id !== product.id));
        addToast('info', 'Prenda retirada del carrito', product.name);
      } else {
        const primary = matchingItems[0];
        setCart((prev) =>
          prev.map((i) => (i.id === primary.id ? { ...i, quantity: newQty } : i))
        );
      }
    } else if (newQty > 0) {
      handleAddToCart(product, product.sizes?.[0] || 'Única', undefined, newQty);
    }
  };

  const handleRemoveFromCart = (itemId: string) => {
    setCart((prevCart) => {
      const item = prevCart.find((i) => i.id === itemId);
      if (item) {
        addToast('info', 'Prenda eliminada del carrito', item.product.name);
      }
      return prevCart.filter((i) => i.id !== itemId);
    });
  };

  const handleClearCart = () => {
    if (cart.length > 0 && confirm('¿Deseas vaciar todos los artículos de tu carrito?')) {
      setCart([]);
      addToast('info', 'Carrito vaciado');
    }
  };

  // --- 🔒 Favorites & Quick Auth Actions ---
  const handleToggleFavorite = (product: Product) => {
    const isFav = favorites.includes(product.id);
    if (isFav) {
      setFavorites((prev) => prev.filter((id) => id !== product.id));
      addToast('favorite', 'Prenda retirada de tus favoritos', product.name);
    } else {
      setFavorites((prev) => [...prev, product.id]);
      addToast('favorite', '¡Guardado en tus favoritos!', product.name);
      // If user is not logged in, suggest quick login
      if (!currentUser?.isLoggedIn) {
        setTimeout(() => {
          setIsAuthOpen(true);
        }, 1000);
      }
    }
  };

  const handleRemoveFavoriteById = (productId: string) => {
    setFavorites((prev) => prev.filter((id) => id !== productId));
    addToast('favorite', 'Prenda retirada de tus favoritos');
  };

  const handleAddAllFavoritesToCart = () => {
    const favProducts = products.filter((p) => favorites.includes(p.id) && p.inStock);
    if (favProducts.length === 0) return;

    favProducts.forEach((p) => {
      handleAddToCart(p, p.sizes?.[0] || 'Única');
    });

    setIsFavoritesOpen(false);
    setIsCartOpen(true);
    addToast('cart', '¡Prendas agregadas al carrito!', `${favProducts.length} producto(s) añadidos`);
  };

  const handleLoginUser = (user: UserAccount) => {
    setCurrentUser(user);
    addToast('info', `¡Bienvenida/o, ${user.name}!`, 'Tus favoritos y datos quedaron sincronizados');
  };

  const handleLogoutUser = () => {
    setCurrentUser(null);
    addToast('info', 'Sesión cerrada');
  };

  // --- Admin Product Actions ---
  const handleSaveProduct = (product: Product) => {
    setProducts((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.map((p) => (p.id === product.id ? product : p));
      } else {
        return [product, ...prev];
      }
    });
    addToast('info', 'Catálogo actualizado', product.name);
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    setCart((prev) => prev.filter((i) => i.product.id !== productId));
    setFavorites((prev) => prev.filter((id) => id !== productId));
    addToast('info', 'Producto eliminado del catálogo');
  };

  const handleResetProducts = () => {
    const defaults = resetProductsToDefault();
    setProducts(defaults);
    addToast('info', 'Catálogo restablecido de fábrica');
  };

  const handleSaveSettings = (newSettings: StoreSettings) => {
    setStoreSettings(newSettings);
    addToast('info', 'Configuración de tienda guardada');
  };

  const handleUpdateOrderStatus = (orderId: string, status: OrderRecord['status']) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status } : o))
    );
    addToast('info', 'Estado de pedido actualizado', `${orderId} -> ${status}`);
  };

  const handleOrderCompleted = (order: OrderRecord) => {
    setOrders((prev) => [order, ...prev]);
  };

  const handleOpenContact = (product?: Product) => {
    setContactProduct(product || null);
    setIsContactOpen(true);
  };

  // --- Computed Values ---
  const totalCartCount = useMemo(
    () => cart.reduce((sum, item) => sum + item.quantity, 0),
    [cart]
  );

  const cartSubtotal = useMemo(
    () => cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0),
    [cart]
  );

  // Filtered & Sorted Products for Display
  const displayedProducts = useMemo(() => {
    let result = products.filter((product) => {
      // Category Filter
      const matchesCategory =
        selectedCategory === 'Todas' || product.category === selectedCategory;

      // Search Filter
      const matchesSearch =
        searchQuery === '' ||
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (product.description && product.description.toLowerCase().includes(searchQuery.toLowerCase()));

      // In Stock Filter
      const matchesStock = showOnlyInStock ? product.inStock : true;

      // Condition Filter (Ropa Nueva / Ropa Usada)
      const matchesCondition =
        conditionFilter === 'all' ||
        (conditionFilter === 'nueva' && product.condition !== 'usada') ||
        (conditionFilter === 'usada' && product.condition === 'usada');

      // Price Range Filter (Prices in Cordobas C$)
      let matchesPrice = true;
      if (priceRange === '10-50') matchesPrice = product.price >= 10 && product.price <= 50;
      else if (priceRange === '50-100') matchesPrice = product.price > 50 && product.price <= 100;
      else if (priceRange === '100-200') matchesPrice = product.price > 100 && product.price <= 200;
      else if (priceRange === '200-500') matchesPrice = product.price > 200 && product.price <= 500;
      else if (priceRange === '500+') matchesPrice = product.price > 500;

      return matchesCategory && matchesSearch && matchesStock && matchesCondition && matchesPrice;
    });

    // Sorting
    if (sortOrder === 'price-asc') {
      result = [...result].sort((a, b) => a.price - b.price);
    } else if (sortOrder === 'price-desc') {
      result = [...result].sort((a, b) => b.price - a.price);
    } else if (sortOrder === 'name-asc') {
      result = [...result].sort((a, b) => a.name.localeCompare(b.name));
    } else {
      // Featured
      result = [...result].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
    }

    return result;
  }, [products, selectedCategory, searchQuery, showOnlyInStock, priceRange, sortOrder]);

  const favoriteProducts = useMemo(() => {
    return products.filter((p) => favorites.includes(p.id));
  }, [products, favorites]);

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-stone-800 pb-24 md:pb-0">
      
      {/* 1. Header with Search, Cart & Favorites Badges, Currency Switcher */}
      <Header
        storeSettings={storeSettings}
        cartCount={totalCartCount}
        cartTotal={cartSubtotal}
        currency={currency}
        onCurrencyChange={setCurrency}
        favoritesCount={favorites.length}
        currentUser={currentUser}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenFavorites={() => setIsFavoritesOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenContact={() => handleOpenContact()}
        onLogout={handleLogoutUser}
      />

      {/* 2. Boutique Hero Banner */}
      <section className="relative overflow-hidden bg-gradient-to-b from-stone-100/70 via-stone-50/50 to-[#FAF8F5] border-b border-stone-200/60 py-7 sm:py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center">
            
            <div className="lg:col-span-7 space-y-3.5 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-100 text-violet-950 text-xs font-bold shadow-2xs">
                <Sparkles className="w-3.5 h-3.5 text-violet-700" />
                <span>Tienda Oficial • Moda & Ropa Femenina en Nicaragua</span>
              </div>

              <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-black text-stone-900 tracking-tight leading-[1.15]">
                {storeSettings.storeName}
              </h1>

              <p className="text-stone-600 text-xs sm:text-sm max-w-xl mx-auto lg:mx-0 leading-relaxed font-medium">
                {storeSettings.tagline}. Agrega prendas al carrito, ajusta cantidades con un toque y pide directamente por WhatsApp con el 20% de descuento aplicado en todo el catálogo.
              </p>

              {/* Badges / Guarantees */}
              <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-2 sm:gap-3 text-[11px] sm:text-xs font-bold text-stone-700">
                <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-stone-200 shadow-2xs">
                  <MessageCircle className="w-4 h-4 text-emerald-600" />
                  <span>Pedidos por WhatsApp</span>
                </div>
                <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-stone-200 shadow-2xs">
                  <Truck className="w-4 h-4 text-violet-600" />
                  <span>Envíos a toda Nicaragua</span>
                </div>
                <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-stone-200 shadow-2xs">
                  <ShieldCheck className="w-4 h-4 text-amber-600" />
                  <span>20% OFF Automático</span>
                </div>
              </div>
            </div>

            {/* Hero Visual Preview */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-sm rounded-3xl overflow-hidden shadow-xl border-4 border-white bg-white group">
                <img
                  src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=85"
                  alt="Colección Boutique El Clóset de Jiet"
                  className="w-full h-64 sm:h-80 object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/85 via-stone-950/20 to-transparent flex flex-col justify-end p-5 text-white">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="bg-amber-400 text-stone-950 font-black text-[10px] px-2 py-0.5 rounded uppercase tracking-wider">
                      OFERTA 20%
                    </span>
                    <span className="text-[10px] uppercase tracking-widest font-bold text-stone-200">
                      Temporada Actual
                    </span>
                  </div>
                  <p className="font-serif text-base sm:text-lg font-bold leading-snug">
                    Estilo, confort y elegancia para toda la familia
                  </p>
                  <button
                    onClick={() => {
                      document.getElementById('catalogo-section')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="mt-2 text-xs font-bold text-rose-200 hover:text-white flex items-center gap-1 group/btn cursor-pointer"
                  >
                    <span>Explorar catálogo disponible</span>
                    <ChevronRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 3. Catalog Section */}
      <main id="catalogo-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10 flex-1 w-full">
        
        {/* inDrive Express & Direct Contact Banner */}
        <div className="mb-6 p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-amber-50 via-rose-50/40 to-violet-50/60 border border-amber-200/90 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-amber-400 text-stone-950 flex items-center justify-center text-2xl shadow-sm shrink-0">
              🛵
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs sm:text-sm font-black text-stone-900">
                  ¿Quieres entrega inmediata hoy en tu puerta?
                </span>
                <span className="bg-amber-400 text-stone-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow-2xs">
                  inDrive Express
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-stone-600 mt-0.5 max-w-2xl leading-relaxed">
                Coordinamos el envío directo con motorizado de inDrive hacia tu ubicación en Managua. O si buscas una talla especial o apartar prendas, déjanos un mensaje.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-stretch sm:self-auto shrink-0">
            <button
              id="btn-banner-open-contact"
              onClick={() => handleOpenContact()}
              className="w-full sm:w-auto px-4 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-95 cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>Dejar Mensaje / Inscribirme</span>
            </button>
          </div>
        </div>

        {/* Category Filter Pills (Matches user's web categories) */}
        <div className="space-y-4 mb-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xs sm:text-sm font-black text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
              <Filter className="w-4 h-4 text-violet-600" />
              <span>Categorías</span>
            </h2>
            <span className="text-[11px] text-stone-500 font-bold">
              {displayedProducts.length} prenda{displayedProducts.length !== 1 ? 's' : ''} disponible{displayedProducts.length !== 1 ? 's' : ''}
            </span>
          </div>

          {/* Horizontal Scrollable Categories */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {PRODUCT_CATEGORIES.map((category) => (
              <button
                key={category}
                id={`cat-filter-${category}`}
                onClick={() => setSelectedCategory(category)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap active:scale-95 cursor-pointer ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-sm ring-2 ring-violet-300'
                    : 'bg-white text-stone-700 hover:text-stone-950 border border-stone-200 hover:border-stone-400'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Secondary Filter Bar: Price Ranges, Condition Filter, Stock Toggle, Sorting */}
          <div className="bg-white p-3 sm:p-4 rounded-2xl border border-stone-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
            
            <div className="flex flex-wrap items-center gap-3">
              {/* Condition Filter (Nueva vs Usada) */}
              <div className="flex items-center gap-1 bg-stone-100 p-0.5 rounded-xl border border-stone-200 shrink-0">
                <button
                  type="button"
                  onClick={() => setConditionFilter('all')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    conditionFilter === 'all'
                      ? 'bg-white text-stone-950 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Todas
                </button>
                <button
                  type="button"
                  onClick={() => setConditionFilter('nueva')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    conditionFilter === 'nueva'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-stone-600 hover:text-emerald-700'
                  }`}
                >
                  <span>✨</span>
                  <span>Ropa Nueva</span>
                </button>
                <button
                  type="button"
                  onClick={() => setConditionFilter('usada')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    conditionFilter === 'usada'
                      ? 'bg-amber-500 text-stone-950 shadow-xs font-black'
                      : 'text-stone-600 hover:text-amber-800'
                  }`}
                >
                  <span>♻️</span>
                  <span>Ropa Usada</span>
                </button>
              </div>

              {/* Price Range Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
                <span className="text-stone-400 font-bold uppercase tracking-wider text-[10px] mr-1 shrink-0">
                  Precio:
                </span>
                {[
                  { id: 'all', label: 'Todos' },
                  { id: '10-50', label: 'C$ 10 - 50' },
                  { id: '50-100', label: 'C$ 50 - 100' },
                  { id: '100-200', label: 'C$ 100 - 200' },
                  { id: '200-500', label: 'C$ 200 - 500' },
                  { id: '500+', label: 'C$ 500+' }
                ].map((range) => (
                  <button
                    key={range.id}
                    onClick={() => setPriceRange(range.id as PriceRangeType)}
                    className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold shrink-0 transition-colors cursor-pointer ${
                      priceRange === range.id
                        ? 'bg-stone-900 text-white'
                        : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                    }`}
                  >
                    {range.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Right Controls: Sort & Stock Toggle */}
            <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-stone-100">
              {/* In Stock Only Toggle */}
              <label className="flex items-center gap-1.5 cursor-pointer text-stone-700 select-none font-bold text-[11px]">
                <input
                  id="toggle-in-stock-only"
                  type="checkbox"
                  checked={showOnlyInStock}
                  onChange={(e) => setShowOnlyInStock(e.target.checked)}
                  className="w-4 h-4 rounded text-violet-600 border-stone-300 focus:ring-violet-500 cursor-pointer"
                />
                <span>Solo en Stock</span>
              </label>

              {/* Sorting Selector */}
              <div className="flex items-center gap-1.5">
                <ArrowUpDown className="w-3.5 h-3.5 text-stone-500" />
                <select
                  id="select-sort-order"
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value as SortOrderType)}
                  className="bg-stone-100 text-stone-800 text-xs font-bold py-1.5 px-2.5 rounded-lg border border-stone-200 focus:outline-none focus:border-stone-400 cursor-pointer"
                >
                  <option value="featured">Destacados</option>
                  <option value="price-asc">Precio: Menor a Mayor</option>
                  <option value="price-desc">Precio: Mayor a Menor</option>
                  <option value="name-asc">Nombre: A - Z</option>
                </select>
              </div>
            </div>

          </div>
        </div>

        {/* Active Search / Filter Indicator */}
        {(searchQuery || selectedCategory !== 'Todas' || priceRange !== 'all') && (
          <div className="mb-6 flex flex-wrap items-center gap-2 text-xs text-stone-600 bg-violet-50/70 p-3 rounded-xl border border-violet-200">
            <span className="font-bold text-violet-950">Filtros activos:</span>
            {selectedCategory !== 'Todas' && (
              <span className="font-bold text-violet-900 bg-white px-2 py-0.5 rounded border border-violet-200">
                Categoría: {selectedCategory}
              </span>
            )}
            {priceRange !== 'all' && (
              <span className="font-bold text-violet-900 bg-white px-2 py-0.5 rounded border border-violet-200">
                Rango: {priceRange}
              </span>
            )}
            {searchQuery && (
              <span className="font-bold text-violet-900 bg-white px-2 py-0.5 rounded border border-violet-200">
                &ldquo;{searchQuery}&rdquo;
              </span>
            )}
            <button
              onClick={() => {
                setSelectedCategory('Todas');
                setSearchQuery('');
                setPriceRange('all');
                setShowOnlyInStock(false);
              }}
              className="ml-auto text-violet-700 hover:text-violet-900 underline font-bold cursor-pointer"
            >
              Restablecer filtros
            </button>
          </div>
        )}

        {/* 4. Product Cards Grid */}
        {displayedProducts.length === 0 ? (
          <div className="py-16 text-center bg-white rounded-3xl border border-stone-200 p-8 space-y-4 max-w-lg mx-auto shadow-xs">
            <div className="w-16 h-16 rounded-full bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
              <ShoppingBag className="w-8 h-8 stroke-[1.5]" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-stone-900">
                No encontramos prendas con esos criterios
              </h3>
              <p className="text-xs text-stone-500 mt-1">
                Intenta cambiar el rango de precio, la categoría o borrar la búsqueda.
              </p>
            </div>
            <button
              onClick={() => {
                setSelectedCategory('Todas');
                setSearchQuery('');
                setPriceRange('all');
                setShowOnlyInStock(false);
              }}
              className="bg-stone-900 text-white text-xs font-bold px-5 py-2.5 rounded-full hover:bg-stone-800 transition-colors shadow-xs cursor-pointer"
            >
              Ver todas las prendas
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
            {displayedProducts.map((product) => {
              const productCartCount = cart
                .filter((i) => i.product.id === product.id)
                .reduce((sum, i) => sum + i.quantity, 0);

              return (
                <ProductCard
                  key={product.id}
                  product={product}
                  currency={currency}
                  exchangeRate={storeSettings.exchangeRate}
                  cartQuantity={productCartCount}
                  isFavorite={favorites.includes(product.id)}
                  onToggleFavorite={handleToggleFavorite}
                  onAddToCart={(prod, qty, size) => handleAddToCart(prod, size, undefined, qty)}
                  onUpdateCartQuantity={handleUpdateProductCartQuantity}
                  onQuickView={setQuickViewProduct}
                />
              );
            })}
          </div>
        )}

        {/* WhatsApp Direct Assistance Banner */}
        <section className="mt-14 bg-gradient-to-r from-emerald-900 via-teal-900 to-stone-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 border border-emerald-800/40">
          <div className="space-y-2 text-center md:text-left">
            <span className="text-xs uppercase tracking-widest text-emerald-300 font-bold">
              ¿Dudas con tu talla, tela o envío?
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold">
              Te atendemos en vivo por WhatsApp
            </h3>
            <p className="text-xs sm:text-sm text-stone-300 max-w-xl">
              Escríbenos al <span className="font-bold text-white font-mono">{storeSettings.whatsappNumber}</span> para coordinar entregas rápidas en Managua o envíos seguros a departamentos.
            </p>
          </div>

          <a
            href={`https://wa.me/50583702337?text=${encodeURIComponent(
              `¡Hola ${storeSettings.storeName}! ✨ Me gustaría recibir asesoría sobre las prendas de su boutique.`
            )}`}
            target="_blank"
            rel="noreferrer"
            className="shrink-0 bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-bold text-xs sm:text-sm px-6 py-3.5 rounded-full shadow-lg flex items-center gap-2 transition-transform active:scale-95 cursor-pointer"
          >
            <MessageCircle className="w-5 h-5 fill-stone-950/20" />
            <span>Chatear por WhatsApp</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </section>

      </main>

      {/* 5. Footer */}
      <footer className="bg-stone-900 text-stone-300 py-10 sm:py-12 border-t border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-8 border-b border-stone-800">
            
            <div className="space-y-3 md:col-span-2">
              <span className="font-serif text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>{storeSettings.storeName}</span>
                <span className="text-xs bg-violet-800 text-violet-100 font-mono px-2 py-0.5 rounded font-bold">
                  Nicaragua
                </span>
              </span>
              <p className="text-xs text-stone-400 max-w-sm leading-relaxed">
                {storeSettings.tagline}. Tienda online con carrito de compras, cálculo de totales, pedidos directos a WhatsApp, favoritos y panel de administración.
              </p>
              {storeSettings.address && (
                <p className="text-xs text-stone-400">
                  📍 {storeSettings.address}
                </p>
              )}
              {storeSettings.bankAccount && (
                <div className="pt-2 text-xs text-stone-400 space-y-0.5">
                  <p className="text-white font-bold flex items-center gap-1.5">
                    <span>💳</span>
                    <span>Cuenta LAFISE: <span className="font-mono text-sky-400">{storeSettings.bankAccount}</span></span>
                  </p>
                  {storeSettings.bankAccountHolder && (
                    <p className="text-[11px] text-stone-400">
                      Titular: <span className="text-stone-300 font-semibold">{storeSettings.bankAccountHolder}</span>
                    </p>
                  )}
                  <p className="text-[11px] text-amber-300 font-semibold pt-1 flex items-center gap-1">
                    <span>🛵</span>
                    <span>Envíos Delivery y con inDrive disponibles</span>
                  </p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Categorías Populares</h4>
              <ul className="text-xs space-y-1.5 text-stone-400">
                {PRODUCT_CATEGORIES.slice(1, 6).map((cat) => (
                  <li key={cat}>
                    <button
                      onClick={() => {
                        setSelectedCategory(cat);
                        window.scrollTo({ top: 350, behavior: 'smooth' });
                      }}
                      className="hover:text-white transition-colors cursor-pointer"
                    >
                      {cat}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Atención y Pedidos</h4>
              <p className="text-xs text-stone-400 leading-relaxed">
                WhatsApp Oficial: <br />
                <span className="font-mono text-emerald-400 font-bold text-sm">
                  {storeSettings.whatsappNumber}
                </span>
              </p>
              <div className="pt-2 space-y-2">
                <button
                  type="button"
                  onClick={() => handleOpenContact()}
                  className="text-xs text-amber-300 hover:text-amber-200 flex items-center gap-1.5 cursor-pointer font-semibold"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-amber-300" />
                  <span>💬 Enviar Mensaje / Inscripción</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsAdminOpen(true)}
                  className="text-xs text-stone-400 hover:text-white flex items-center gap-1.5 cursor-pointer"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-violet-400" />
                  <span>Panel Administrador (PIN)</span>
                </button>
              </div>
            </div>

          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-2">
            <span>© {new Date().getFullYear()} {storeSettings.storeName}. Todos los derechos reservados.</span>
            <span>Hecho para {storeSettings.storeName} • Nicaragua</span>
          </div>
        </div>
      </footer>

      {/* 6. Floating Cart Bar (for fast mobile action if cart has items) */}
      {totalCartCount > 0 && !isCartOpen && (
        <div className="fixed bottom-20 sm:bottom-6 left-3 right-3 sm:left-auto sm:right-6 z-30 max-w-sm sm:w-80 animate-slide-up">
          <button
            id="btn-floating-cart-bar"
            onClick={() => setIsCartOpen(true)}
            className="w-full bg-gradient-to-r from-violet-700 via-purple-700 to-indigo-800 text-white rounded-2xl p-3.5 shadow-2xl flex items-center justify-between border border-violet-500/50 active:scale-98 transition-all cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <ShoppingBag className="w-5 h-5 text-amber-300" />
                <span className="absolute -top-1.5 -right-1.5 bg-rose-500 text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                  {totalCartCount}
                </span>
              </div>
              <span className="text-xs font-black">Ver Mi Carrito ({totalCartCount})</span>
            </div>
            <div className="text-right">
              <span className="text-xs font-black text-amber-300">
                {formatCurrency(cartSubtotal * 0.8, currency, storeSettings.exchangeRate)}
              </span>
            </div>
          </button>
        </div>
      )}

      {/* 7. Mobile Bottom Navigation Bar */}
      <MobileNav
        activeTab="catalog"
        cartCount={totalCartCount}
        cartTotal={cartSubtotal}
        currency={currency}
        storeSettings={storeSettings}
        favoritesCount={favorites.length}
        currentUser={currentUser}
        onOpenCatalog={() => {
          setSelectedCategory('Todas');
          setSearchQuery('');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenFavorites={() => setIsFavoritesOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      {/* 8. Slide-over Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        currency={currency}
        onCurrencyChange={setCurrency}
        storeSettings={storeSettings}
        currentUser={currentUser}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onOrderCompleted={handleOrderCompleted}
      />

      {/* 9. Product Detail & Photo Gallery Modal */}
      <ProductDetailModal
        product={quickViewProduct}
        currency={currency}
        storeSettings={storeSettings}
        isFavorite={quickViewProduct ? favorites.includes(quickViewProduct.id) : false}
        onClose={() => setQuickViewProduct(null)}
        onAddToCart={handleAddToCart}
        onToggleFavorite={handleToggleFavorite}
      />

      {/* 10. Favorites Drawer */}
      <FavoritesDrawer
        isOpen={isFavoritesOpen}
        onClose={() => setIsFavoritesOpen(false)}
        favorites={favoriteProducts}
        currency={currency}
        storeSettings={storeSettings}
        onRemoveFavorite={handleRemoveFavoriteById}
        onAddToCart={(prod) => handleAddToCart(prod, prod.sizes?.[0] || 'Única')}
        onAddAllToCart={handleAddAllFavoritesToCart}
      />

      {/* 11. Quick Auth / User Profile Modal */}
      <QuickAuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        currentUser={currentUser}
        onLogin={handleLoginUser}
        onLogout={handleLogoutUser}
      />

      {/* 12. Admin Management Modal */}
      <AdminModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        products={products}
        storeSettings={storeSettings}
        orders={orders}
        onSaveProduct={handleSaveProduct}
        onDeleteProduct={handleDeleteProduct}
        onResetProducts={handleResetProducts}
        onSaveSettings={handleSaveSettings}
        onUpdateOrderStatus={handleUpdateOrderStatus}
      />

      {/* 13. Customer Inquiry / Contact Modal */}
      <ContactModal
        isOpen={isContactOpen}
        onClose={() => {
          setIsContactOpen(false);
          setContactProduct(null);
        }}
        storeSettings={storeSettings}
        product={contactProduct}
        onInquirySaved={() => {
          addToast('info', '¡Mensaje guardado!', 'El dueño se pondrá en contacto pronto.');
        }}
      />

      {/* Quick Floating WhatsApp / Contact Inquiry Button */}
      {!isContactOpen && !isCartOpen && (
        <button
          id="btn-floating-quick-contact"
          onClick={() => handleOpenContact()}
          className="fixed bottom-24 md:bottom-6 right-4 md:right-6 z-20 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full p-3.5 md:px-4 md:py-2.5 shadow-xl flex items-center gap-2 border-2 border-white transition-all hover:scale-105 active:scale-95 cursor-pointer group"
          title="Enviar mensaje / Contactar al dueño"
        >
          <MessageCircle className="w-5 h-5 text-white" />
          <span className="hidden md:inline text-xs font-bold">Mensaje / inDrive</span>
        </button>
      )}

      {/* 14. Floating Toasts */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

    </div>
  );
}
