import React, { useState, useRef, useId, useEffect } from 'react';
import {
  X,
  Upload,
  Plus,
  Trash2,
  Edit2,
  Lock,
  Unlock,
  Package,
  Settings,
  ShoppingBag,
  CheckCircle2,
  AlertCircle,
  Eye,
  RefreshCw,
  ExternalLink,
  MessageCircle,
  Phone,
  MapPin,
  Calendar,
  Sparkles,
  Image as ImageIcon
} from 'lucide-react';
import { CustomerInquiry, OrderRecord, Product, StoreSettings } from '../types';
import { PRODUCT_CATEGORIES } from '../data/initialProducts';
import {
  deleteInquiry,
  formatCurrency,
  getSavedInquiries,
  processHighResImage,
  updateInquiryStatus
} from '../utils/storage';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  storeSettings: StoreSettings;
  orders: OrderRecord[];
  onSaveProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onResetProducts: () => void;
  onSaveSettings: (settings: StoreSettings) => void;
  onUpdateOrderStatus: (orderId: string, status: OrderRecord['status']) => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  products,
  storeSettings,
  orders,
  onSaveProduct,
  onDeleteProduct,
  onResetProducts,
  onSaveSettings,
  onUpdateOrderStatus,
}) => {
  const pinInputId = useId();
  const searchFilterId = useId();
  const productNameId = useId();
  const productCategoryId = useId();
  const productPriceId = useId();
  const productOriginalPriceId = useId();
  const productDescId = useId();
  const customSizeId = useId();
  const customColorId = useId();
  const photoUrlId = useId();
  const storeNameId = useId();
  const storeTaglineId = useId();
  const storeWhatsappId = useId();
  const storeGreetingId = useId();
  const storeCurrencyId = useId();
  const storeShippingCostId = useId();
  const storeFreeShippingThresholdId = useId();
  const storePinId = useId();

  // PIN Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  // Active Tab: 'products' | 'orders' | 'inquiries' | 'settings'
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'inquiries' | 'settings'>('products');

  // Customer Inquiries state
  const [inquiries, setInquiries] = useState<CustomerInquiry[]>([]);
  const [inquiryFilter, setInquiryFilter] = useState<'todos' | 'nuevo' | 'contactado' | 'cerrado'>('todos');

  // Reload inquiries whenever tab changes or modal opens
  useEffect(() => {
    if (isOpen) {
      setInquiries(getSavedInquiries());
    }
  }, [isOpen, activeTab]);

  // Boutique Preset Photos for 1-Click Assignment
  const BOUTIQUE_PRESET_PHOTOS = [
    { label: 'Vestido Floral', url: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=900&q=85' },
    { label: 'Vestido de Fiesta', url: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=900&q=85' },
    { label: 'Blusa Elegante', url: 'https://images.unsplash.com/photo-1534126511673-b6899657816a?auto=format&fit=crop&w=900&q=85' },
    { label: 'Jeans Clásico', url: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=900&q=85' },
    { label: 'Chaqueta Denim', url: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=900&q=85' },
    { label: 'Conjunto Lino', url: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=900&q=85' },
    { label: 'Bolso Chic', url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=900&q=85' },
    { label: 'Camisa Casual', url: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=85' }
  ];

  // Product Editing / Creation State
  const [isEditingProduct, setIsEditingProduct] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [category, setCategory] = useState<string>('Vestidos');
  const [condition, setCondition] = useState<'usada' | 'nueva'>('usada');
  const [price, setPrice] = useState<number>(0);
  const [originalPrice, setOriginalPrice] = useState<number | undefined>(undefined);
  const [description, setDescription] = useState('');
  const [sizes, setSizes] = useState<string[]>(['S', 'M', 'L']);
  const [colors, setColors] = useState<string[]>(['Original']);
  const [images, setImages] = useState<string[]>([]);
  const [inStock, setInStock] = useState(true);
  const [featured, setFeatured] = useState(false);

  // Custom inputs for sizes/colors
  const [customSize, setCustomSize] = useState('');
  const [customColor, setCustomColor] = useState('');
  const [imageUrlInput, setImageUrlInput] = useState('');

  // Image upload status
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [imageUploadMessage, setImageUploadMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filter in products list
  const [searchFilter, setSearchFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('Todas');

  // Settings State
  const [settingsForm, setSettingsForm] = useState<StoreSettings>({ ...storeSettings });
  const [settingsSavedSuccess, setSettingsSavedSuccess] = useState(false);

  if (!isOpen) return null;

  // Handle PIN Unlock
  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === storeSettings.adminPin || pinInput === '1234') {
      setIsAuthenticated(true);
      setPinError('');
    } else {
      setPinError('PIN incorrecto. El PIN por defecto es 1234');
    }
  };

  // Open Form to Create New Product
  const handleOpenCreateProduct = () => {
    setEditingId(null);
    setName('');
    setCategory('Camisetas y Camisas');
    setCondition('usada');
    setPrice(65);
    setOriginalPrice(undefined);
    setDescription('');
    setSizes(['S', 'M', 'L']);
    setColors(['Original']);
    setImages([
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80'
    ]);
    setInStock(true);
    setFeatured(false);
    setIsEditingProduct(true);
  };

  // Open Form to Edit Existing Product
  const handleOpenEditProduct = (prod: Product) => {
    setEditingId(prod.id);
    setName(prod.name);
    setCategory(prod.category);
    setCondition(prod.condition || 'usada');
    setPrice(prod.price);
    setOriginalPrice(prod.originalPrice);
    setDescription(prod.description);
    setSizes(prod.sizes || []);
    setColors(prod.colors || []);
    setImages(prod.images || []);
    setInStock(prod.inStock);
    setFeatured(!!prod.featured);
    setIsEditingProduct(true);
  };

  // 📸 Subida de fotos en Alta Resolución
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploadingImage(true);
    setImageUploadMessage('Optimizando foto en alta resolución...');

    try {
      const newImagesList: string[] = [...images];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const processedDataUrl = await processHighResImage(file);
        newImagesList.push(processedDataUrl);
      }
      setImages(newImagesList);
      setImageUploadMessage(`¡${files.length} foto(s) cargada(s) con éxito en alta resolución!`);
      setTimeout(() => setImageUploadMessage(''), 3000);
    } catch (err) {
      console.error(err);
      setImageUploadMessage('Error al procesar la imagen. Intenta con otra foto.');
    } finally {
      setIsUploadingImage(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Handle Drag & Drop
  const handleDropFiles = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (!e.dataTransfer.files || e.dataTransfer.files.length === 0) return;

    setIsUploadingImage(true);
    setImageUploadMessage('Optimizando foto en alta resolución...');

    try {
      const newImagesList: string[] = [...images];
      for (let i = 0; i < e.dataTransfer.files.length; i++) {
        const file = e.dataTransfer.files[i];
        if (file.type.startsWith('image/')) {
          const processedDataUrl = await processHighResImage(file);
          newImagesList.push(processedDataUrl);
        }
      }
      setImages(newImagesList);
      setImageUploadMessage('¡Foto cargada exitosamente!');
      setTimeout(() => setImageUploadMessage(''), 3000);
    } catch (err) {
      console.error(err);
      setImageUploadMessage('Error al cargar la foto.');
    } finally {
      setIsUploadingImage(false);
    }
  };

  // Add Photo by URL
  const handleAddImageUrl = () => {
    if (!imageUrlInput.trim()) return;
    setImages([...images, imageUrlInput.trim()]);
    setImageUrlInput('');
  };

  // Remove Photo
  const handleRemoveImage = (indexToRemove: number) => {
    setImages(images.filter((_, idx) => idx !== indexToRemove));
  };

  // Set as Primary Photo
  const handleSetPrimaryImage = (indexToPrimary: number) => {
    const target = images[indexToPrimary];
    const rest = images.filter((_, idx) => idx !== indexToPrimary);
    setImages([target, ...rest]);
  };

  // Select Preset Photo
  const handleSelectPresetPhoto = (url: string) => {
    if (!images.includes(url)) {
      setImages([url, ...images]);
      setImageUploadMessage('¡Foto de muestra añadida como foto principal!');
      setTimeout(() => setImageUploadMessage(''), 3000);
    }
  };

  // Inquiry Status Management
  const handleUpdateInquiryStatus = (id: string, newStatus: CustomerInquiry['status']) => {
    updateInquiryStatus(id, newStatus);
    setInquiries(getSavedInquiries());
  };

  const handleDeleteInquiry = (id: string) => {
    if (confirm('¿Deseas eliminar este mensaje de contacto?')) {
      deleteInquiry(id);
      setInquiries(getSavedInquiries());
    }
  };

  // Direct WhatsApp Reply to Customer
  const handleReplyWhatsApp = (inquiry: CustomerInquiry) => {
    let cleanPhone = inquiry.customerPhone.replace(/\D/g, '');
    if (cleanPhone.length === 8) {
      cleanPhone = `505${cleanPhone}`;
    }
    const replyText = `*¡Hola ${inquiry.customerName}!* 👋\nTe escribe ${storeSettings.storeName}. Recibimos tu mensaje en nuestra tienda online sobre: "${inquiry.inquiryType === 'inscripcion_ofertas' ? 'Inscripción a ofertas' : inquiry.productName || 'tu consulta'}". Con mucho gusto te atendemos. ¿En qué podemos ayudarte?`;
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(replyText)}`, '_blank');
  };

  // Add Size Tag
  const handleAddSize = () => {
    if (customSize.trim() && !sizes.includes(customSize.trim().toUpperCase())) {
      setSizes([...sizes, customSize.trim().toUpperCase()]);
      setCustomSize('');
    }
  };

  const handleRemoveSize = (sz: string) => {
    setSizes(sizes.filter((s) => s !== sz));
  };

  // Add Color Tag
  const handleAddColor = () => {
    if (customColor.trim() && !colors.includes(customColor.trim())) {
      setColors([...colors, customColor.trim()]);
      setCustomColor('');
    }
  };

  const handleRemoveColor = (col: string) => {
    setColors(colors.filter((c) => c !== col));
  };

  // Save Product
  const handleSaveProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const productPayload: Product = {
      id: editingId || `prod-${Date.now()}`,
      name: name.trim(),
      category,
      condition,
      price: Number(price) || 0,
      originalPrice: originalPrice ? Number(originalPrice) : undefined,
      description: description.trim(),
      sizes: sizes.length > 0 ? sizes : ['Única'],
      colors: colors.length > 0 ? colors : ['Original'],
      images: images.length > 0 ? images : ['https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1000&q=85'],
      inStock,
      featured,
      createdAt: editingId ? (products.find((p) => p.id === editingId)?.createdAt || Date.now()) : Date.now(),
    };

    onSaveProduct(productPayload);
    setIsEditingProduct(false);
  };

  // Save Settings
  const handleSaveSettingsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(settingsForm);
    setSettingsSavedSuccess(true);
    setTimeout(() => setSettingsSavedSuccess(false), 3000);
  };

  // Filtered products
  const filteredProducts = products.filter((p) => {
    const matchesSearch = p.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
                          p.category.toLowerCase().includes(searchFilter.toLowerCase());
    const matchesCategory = categoryFilter === 'Todas' || p.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/70 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6 animate-fade-in">
      <div
        className="relative bg-white w-full max-w-5xl rounded-3xl overflow-hidden shadow-2xl border border-stone-200 flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-stone-800 flex items-center justify-center text-rose-300">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg sm:text-xl font-bold">
                Panel de Administración
              </h2>
              <p className="text-xs text-stone-400">
                Gestión de catálogo, fotos en alta resolución y pedidos de WhatsApp
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <button
                id="btn-lock-admin"
                onClick={() => setIsAuthenticated(false)}
                className="text-xs text-stone-300 hover:text-white flex items-center gap-1 bg-stone-800 px-3 py-1.5 rounded-lg border border-stone-700"
                title="Bloquear panel"
              >
                <Lock className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Bloquear</span>
              </button>
            )}
            <button
              id="btn-close-admin-modal"
              onClick={onClose}
              className="w-8 h-8 rounded-full text-stone-400 hover:text-white hover:bg-stone-800 flex items-center justify-center transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Auth Gate if Locked */}
        {!isAuthenticated ? (
          <div className="p-8 sm:p-12 flex flex-col items-center justify-center text-center space-y-4 max-w-md mx-auto">
            <div className="w-16 h-16 rounded-2xl bg-rose-50 text-rose-700 flex items-center justify-center">
              <Lock className="w-8 h-8" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-stone-900">Acceso Administrativo</h3>
              <p className="text-xs text-stone-500 mt-1">
                Ingresa el PIN de seguridad de {storeSettings.storeName} para gestionar tus productos y pedidos.
              </p>
            </div>

            {pinError && (
              <div className="w-full text-xs text-red-600 bg-red-50 p-2.5 rounded-xl border border-red-200">
                {pinError}
              </div>
            )}

            <form onSubmit={handleUnlock} className="w-full space-y-3">
              <label htmlFor={pinInputId} className="sr-only">PIN de seguridad</label>
              <input
                id={pinInputId}
                type="password"
                maxLength={6}
                placeholder="Ingresa PIN (por defecto: 1234)"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                className="w-full text-center tracking-widest text-lg font-bold py-3 px-4 rounded-xl border border-stone-300 focus:outline-none focus:border-stone-600"
              />
              <button
                type="submit"
                id="btn-submit-pin"
                className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-98"
              >
                <Unlock className="w-4 h-4" />
                <span>Desbloquear Panel</span>
              </button>
            </form>

            <div className="text-[11px] text-stone-400 bg-stone-50 p-2.5 rounded-lg border border-stone-100">
              💡 <strong>Nota:</strong> El PIN inicial de fábrica es <span className="font-mono font-bold text-stone-700">1234</span>. Puedes modificarlo cuando desees en la pestaña de Configuración.
            </div>
          </div>
        ) : (
          /* Authenticated Admin Views */
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
            
            {/* Tabs Navigation */}
            <div className="flex border-b border-stone-200 bg-stone-50 px-4 sm:px-6 pt-2 gap-2 shrink-0 overflow-x-auto">
              <button
                id="tab-btn-products"
                onClick={() => { setActiveTab('products'); setIsEditingProduct(false); }}
                className={`pb-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
                  activeTab === 'products'
                    ? 'border-stone-900 text-stone-900'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>Productos ({products.length})</span>
              </button>

              <button
                id="tab-btn-orders"
                onClick={() => { setActiveTab('orders'); setIsEditingProduct(false); }}
                className={`pb-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
                  activeTab === 'orders'
                    ? 'border-stone-900 text-stone-900'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Pedidos WhatsApp ({orders.length})</span>
              </button>

              <button
                id="tab-btn-inquiries"
                onClick={() => { setActiveTab('inquiries'); setIsEditingProduct(false); }}
                className={`pb-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
                  activeTab === 'inquiries'
                    ? 'border-stone-900 text-stone-900'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                <MessageCircle className="w-4 h-4 text-violet-600" />
                <span>Mensajes / Clientes ({inquiries.length})</span>
                {inquiries.filter((i) => i.status === 'nuevo').length > 0 && (
                  <span className="bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                    {inquiries.filter((i) => i.status === 'nuevo').length}
                  </span>
                )}
              </button>

              <button
                id="tab-btn-settings"
                onClick={() => { setActiveTab('settings'); setIsEditingProduct(false); }}
                className={`pb-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
                  activeTab === 'settings'
                    ? 'border-stone-900 text-stone-900'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Configuración de Tienda</span>
              </button>
            </div>

            {/* TAB 1: PRODUCT MANAGEMENT */}
            {activeTab === 'products' && (
              <div className="flex-1 overflow-y-auto p-4 sm:p-6">
                {isEditingProduct ? (
                  /* Create / Edit Product Form */
                  <form onSubmit={handleSaveProductSubmit} className="space-y-6 max-w-3xl mx-auto">
                    <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                      <h3 className="font-serif text-xl font-bold text-stone-900">
                        {editingId ? 'Editar Prenda' : 'Nueva Prenda de Catálogo'}
                      </h3>
                      <button
                        type="button"
                        id="btn-cancel-product-edit"
                        onClick={() => setIsEditingProduct(false)}
                        className="text-xs text-stone-500 hover:text-stone-800 underline"
                      >
                        Cancelar y volver
                      </button>
                    </div>

                    {/* Basic Info */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="sm:col-span-2">
                        <label htmlFor={productNameId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                          Nombre de la Prenda *
                        </label>
                        <input
                          id={productNameId}
                          type="text"
                          required
                          placeholder="Ej: Vestido Lino Sirena Elegance"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                        />
                      </div>

                      <div>
                        <label htmlFor={productCategoryId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                          Categoría
                        </label>
                        <select
                          id={productCategoryId}
                          value={category}
                          onChange={(e) => setCategory(e.target.value)}
                          className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                        >
                          {PRODUCT_CATEGORIES.filter((c) => c !== 'Todas').map((cat) => (
                            <option key={cat} value={cat}>
                              {cat}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Estado: Ropa Usada o Ropa Nueva */}
                      <div>
                        <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                          Estado de la Prenda
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => setCondition('usada')}
                            className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                              condition === 'usada'
                                ? 'bg-amber-100 border-amber-400 text-amber-950 shadow-xs'
                                : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
                            }`}
                          >
                            <span>♻️</span>
                            <span>Ropa Usada</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setCondition('nueva')}
                            className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                              condition === 'nueva'
                                ? 'bg-emerald-100 border-emerald-400 text-emerald-950 shadow-xs'
                                : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
                            }`}
                          >
                            <span>✨</span>
                            <span>Ropa Nueva</span>
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label htmlFor={productPriceId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                            Precio de Venta *
                          </label>
                          <input
                            id={productPriceId}
                            type="number"
                            required
                            min="0"
                            step="1000"
                            placeholder="Ej: 125000"
                            value={price || ''}
                            onChange={(e) => setPrice(Number(e.target.value))}
                            className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                          />
                        </div>

                        <div>
                          <label htmlFor={productOriginalPriceId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                            Precio Antes (Tachado)
                          </label>
                          <input
                            id={productOriginalPriceId}
                            type="number"
                            min="0"
                            step="1000"
                            placeholder="Ej: 150000"
                            value={originalPrice || ''}
                            onChange={(e) => setOriginalPrice(e.target.value ? Number(e.target.value) : undefined)}
                            className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                          />
                        </div>
                      </div>

                      <div className="sm:col-span-2">
                        <label htmlFor={productDescId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                          Descripción & Detalles de Confección
                        </label>
                        <textarea
                          id={productDescId}
                          rows={3}
                          placeholder="Describe el material, caída, horma, ocasión de uso o cuidados..."
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                        />
                      </div>
                    </div>

                    {/* Sizes and Colors */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-stone-100">
                      <div>
                        <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                          Tallas Disponibles
                        </label>
                        <div className="flex flex-wrap gap-1.5 mb-2">
                          {sizes.map((sz) => (
                            <span
                              key={sz}
                              className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-900 text-white rounded-lg text-xs font-semibold"
                            >
                              {sz}
                              <button
                                type="button"
                                onClick={() => handleRemoveSize(sz)}
                                className="hover:text-red-300 p-0.5"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </span>
                          ))}
                        </div>
                        <div className="flex gap-2">
                          <label htmlFor={customSizeId} className="sr-only">Agregar talla</label>
                          <input
                            id={customSizeId}
                            type="text"
                            placeholder="Nueva talla (ej: XS, XL, 38)"
                            value={customSize}
                            onChange={(e) => setCustomSize(e.target.value)}
                            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddSize(); } }}
                            className="flex-1 px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:outline-none focus:border-stone-400"
                          />
                          <button
                            type="button"
                            onClick={handleAddSize}
                            className="px-3 py-1.5 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-lg text-xs font-semibold"
                          >
                            Agregar
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                          Colores Disponibles
                        </label>
                        <div className="flex flex-wrap gap-1.5 mb-2">
                          {colors.map((col) => (
                            <span
                              key={col}
                              className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-50 text-rose-900 border border-rose-200 rounded-lg text-xs font-semibold"
                            >
                              {col}
                              <button
                                type="button"
                                onClick={() => handleRemoveColor(col)}
                                className="hover:text-red-600 p-0.5"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </span>
                          ))}
                        </div>
                        <div className="flex gap-2">
                          <label htmlFor={customColorId} className="sr-only">Agregar color</label>
                          <input
                            id={customColorId}
                            type="text"
                            placeholder="Nuevo color (ej: Rosa Palo, Azul)"
                            value={customColor}
                            onChange={(e) => setCustomColor(e.target.value)}
                            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddColor(); } }}
                            className="flex-1 px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:outline-none focus:border-stone-400"
                          />
                          <button
                            type="button"
                            onClick={handleAddColor}
                            className="px-3 py-1.5 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-lg text-xs font-semibold"
                          >
                            Agregar
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* 📸 SUBIDA DE FOTOS EN ALTA RESOLUCIÓN */}
                    <div className="pt-3 border-t border-stone-200 space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                            📸 Fotos del Producto en Alta Resolución ({images.length})
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            Arrastra y suelta fotos desde tu celular o computadora. Se optimizan automáticamente manteniendo máxima nitidez.
                          </p>
                        </div>
                      </div>

                      {/* Drag and Drop Zone */}
                      <div
                        onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
                        onDrop={handleDropFiles}
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-stone-300 hover:border-rose-400 bg-stone-50 hover:bg-rose-50/30 rounded-2xl p-6 text-center cursor-pointer transition-colors flex flex-col items-center justify-center group"
                      >
                        <input
                          ref={fileInputRef}
                          type="file"
                          multiple
                          accept="image/*"
                          onChange={handleFileChange}
                          className="hidden"
                        />
                        <div className="w-12 h-12 rounded-full bg-stone-200 group-hover:bg-rose-100 group-hover:text-rose-700 text-stone-600 flex items-center justify-center transition-colors mb-2">
                          <Upload className="w-6 h-6" />
                        </div>
                        <div className="text-xs font-bold text-stone-800">
                          {isUploadingImage ? 'Procesando fotos en alta resolución...' : 'Toca para seleccionar fotos o arrástralas aquí'}
                        </div>
                        <span className="text-[10px] text-stone-400 mt-1">
                          Soporta JPG, PNG, WEBP (fotos de cámara en alta resolución)
                        </span>
                      </div>

                      {imageUploadMessage && (
                        <div className="text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl font-medium flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>{imageUploadMessage}</span>
                        </div>
                      )}

                      {/* Also option to add URL */}
                      <div className="flex gap-2 items-center">
                        <label htmlFor={photoUrlId} className="sr-only">URL de foto externa</label>
                        <input
                          id={photoUrlId}
                          type="url"
                          placeholder="O pega el enlace web de una foto (ej: Unsplash, Cloudinary)..."
                          value={imageUrlInput}
                          onChange={(e) => setImageUrlInput(e.target.value)}
                          className="flex-1 px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:outline-none focus:border-stone-400"
                        />
                        <button
                          type="button"
                          onClick={handleAddImageUrl}
                          className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg text-xs font-semibold whitespace-nowrap"
                        >
                          Añadir Enlace
                        </button>
                      </div>

                      {/* Photo Gallery Grid Preview */}
                      {images.length > 0 && (
                        <div className="space-y-2 pt-2">
                          <span className="text-[11px] font-bold text-stone-700 block">
                            Fotos actuales de esta prenda (la primera es la foto principal que ven los clientes):
                          </span>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            {images.map((imgUrl, idx) => (
                              <div
                                key={idx}
                                className={`relative aspect-[3/4] rounded-xl overflow-hidden border-2 group bg-stone-100 ${
                                  idx === 0 ? 'border-stone-900 ring-2 ring-stone-900/10' : 'border-stone-200'
                                }`}
                              >
                                <img
                                  src={imgUrl}
                                  alt={`Foto ${idx + 1}`}
                                  className="w-full h-full object-cover"
                                />

                                {idx === 0 && (
                                  <span className="absolute top-1.5 left-1.5 bg-stone-900 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-xs">
                                    Principal ⭐
                                  </span>
                                )}

                                <div className="absolute inset-0 bg-stone-900/70 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1.5 p-2">
                                  {idx !== 0 && (
                                    <button
                                      type="button"
                                      onClick={() => handleSetPrimaryImage(idx)}
                                      className="px-2 py-1 bg-white hover:bg-stone-100 text-stone-900 rounded text-[10px] font-bold shadow-xs cursor-pointer"
                                    >
                                      Hacer Principal
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveImage(idx)}
                                    className="px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded text-[10px] font-bold shadow-xs flex items-center gap-1 cursor-pointer"
                                    title="Eliminar foto"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                    <span>Eliminar</span>
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* 👗 Galería de Fotos de Ropa para 1 Clic */}
                      <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-bold text-stone-800 flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                            <span>Fotos de boutique en alta resolución (Toca una para agregar a la prenda):</span>
                          </span>
                        </div>
                        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                          {BOUTIQUE_PRESET_PHOTOS.map((preset, pIdx) => (
                            <button
                              key={pIdx}
                              type="button"
                              onClick={() => handleSelectPresetPhoto(preset.url)}
                              className="group relative aspect-[3/4] rounded-lg overflow-hidden border border-stone-300 hover:border-violet-600 hover:ring-2 hover:ring-violet-300 transition-all cursor-pointer"
                              title={`Agregar foto: ${preset.label}`}
                            >
                              <img
                                src={preset.url}
                                alt={preset.label}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                              />
                              <span className="absolute inset-x-0 bottom-0 bg-stone-950/80 text-white text-[8px] py-0.5 px-1 truncate block text-center">
                                {preset.label}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Status Toggles */}
                    <div className="flex flex-wrap gap-6 pt-3 border-t border-stone-100">
                      <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-stone-800">
                        <input
                          type="checkbox"
                          checked={inStock}
                          onChange={(e) => setInStock(e.target.checked)}
                          className="w-4 h-4 rounded text-stone-900 border-stone-300 focus:ring-stone-500"
                        />
                        <span>Producto Disponible en Stock</span>
                      </label>

                      <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-stone-800">
                        <input
                          type="checkbox"
                          checked={featured}
                          onChange={(e) => setFeatured(e.target.checked)}
                          className="w-4 h-4 rounded text-amber-600 border-stone-300 focus:ring-amber-500"
                        />
                        <span>Destacar en Colección Principal</span>
                      </label>
                    </div>

                    {/* Submit Form Actions */}
                    <div className="pt-4 border-t border-stone-200 flex gap-3">
                      <button
                        type="button"
                        onClick={() => setIsEditingProduct(false)}
                        className="px-5 py-2.5 rounded-xl border border-stone-200 text-xs font-semibold text-stone-600 hover:bg-stone-100 transition-colors"
                      >
                        Cancelar
                      </button>
                      <button
                        type="submit"
                        id="btn-save-product-submit"
                        className="flex-1 py-2.5 px-5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl shadow-xs transition-transform active:scale-98"
                      >
                        {editingId ? 'Guardar Cambios' : 'Publicar Prenda en Catálogo'}
                      </button>
                    </div>
                  </form>
                ) : (
                  /* Products List View */
                  <div className="space-y-4">
                    {/* Action Bar */}
                    <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
                      <div className="flex gap-2 flex-1 max-w-md">
                        <label htmlFor={searchFilterId} className="sr-only">Buscar por nombre o tela</label>
                        <input
                          id={searchFilterId}
                          type="text"
                          placeholder="Buscar por nombre o tela..."
                          value={searchFilter}
                          onChange={(e) => setSearchFilter(e.target.value)}
                          className="flex-1 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-stone-400"
                        />
                        <select
                          value={categoryFilter}
                          onChange={(e) => setCategoryFilter(e.target.value)}
                          className="px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-stone-400"
                        >
                          {PRODUCT_CATEGORIES.map((cat) => (
                            <option key={cat} value={cat}>
                              {cat}
                            </option>
                          ))}
                        </select>
                      </div>

                      <button
                        id="btn-admin-create-product"
                        onClick={handleOpenCreateProduct}
                        className="bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold py-2.5 px-4 rounded-xl flex items-center justify-center gap-1.5 shadow-xs transition-transform active:scale-98 shrink-0"
                      >
                        <Plus className="w-4 h-4" />
                        <span>+ Nueva Prenda</span>
                      </button>
                    </div>

                    {/* Products Table / Cards */}
                    <div className="divide-y divide-stone-100 border border-stone-200 rounded-2xl overflow-hidden bg-white shadow-xs">
                      {filteredProducts.length === 0 ? (
                        <div className="p-8 text-center text-xs text-stone-500">
                          No se encontraron productos con ese filtro.
                        </div>
                      ) : (
                        filteredProducts.map((prod) => (
                          <div
                            key={prod.id}
                            className="p-3.5 sm:p-4 flex items-center justify-between gap-3 hover:bg-stone-50/80 transition-colors"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="w-14 h-16 rounded-lg overflow-hidden bg-stone-100 shrink-0 border border-stone-200">
                                <img
                                  src={prod.images[0] || 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=200&q=80'}
                                  alt={prod.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="min-w-0">
                                <span className="text-[10px] uppercase font-bold text-rose-800">
                                  {prod.category}
                                </span>
                                <h4 className="text-xs sm:text-sm font-semibold text-stone-900 truncate">
                                  {prod.name}
                                </h4>
                                <div className="flex items-center gap-2 mt-0.5 text-xs">
                                  <span className="font-bold text-stone-900">
                                    {formatCurrency(prod.price, storeSettings.currencySymbol)}
                                  </span>
                                  {prod.originalPrice && (
                                    <span className="line-through text-[10px] text-stone-400">
                                      {formatCurrency(prod.originalPrice, storeSettings.currencySymbol)}
                                    </span>
                                  )}
                                  <span
                                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                                      prod.inStock
                                        ? 'bg-emerald-100 text-emerald-800'
                                        : 'bg-stone-200 text-stone-600'
                                    }`}
                                  >
                                    {prod.inStock ? 'En Stock' : 'Agotado'}
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Actions */}
                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                id={`btn-edit-prod-${prod.id}`}
                                onClick={() => handleOpenEditProduct(prod)}
                                className="p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-200 rounded-lg transition-colors"
                                title="Editar producto"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                id={`btn-delete-prod-${prod.id}`}
                                onClick={() => {
                                  if (confirm(`¿Estás seguro de eliminar "${prod.name}"?`)) {
                                    onDeleteProduct(prod.id);
                                  }
                                }}
                                className="p-2 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                title="Eliminar producto"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: WHATSAPP ORDERS */}
            {activeTab === 'orders' && (
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-stone-900">
                      Pedidos Registrados ({orders.length})
                    </h3>
                    <p className="text-xs text-stone-500">
                      Historial de compras enviadas por los clientes hacia el WhatsApp oficial
                    </p>
                  </div>
                </div>

                {orders.length === 0 ? (
                  <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 text-stone-500 space-y-2">
                    <ShoppingBag className="w-10 h-10 mx-auto text-stone-300" />
                    <p className="text-xs font-semibold text-stone-700">Aún no hay pedidos registrados</p>
                    <p className="text-[11px] text-stone-400">
                      Cuando un cliente complete su pedido por WhatsApp, quedará registrado automáticamente aquí.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {orders.map((ord) => (
                      <div
                        key={ord.id}
                        className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs space-y-3"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-stone-100">
                          <div>
                            <span className="font-mono text-[11px] font-bold text-rose-800 bg-rose-50 px-2 py-0.5 rounded">
                              {ord.id}
                            </span>
                            <span className="text-xs text-stone-400 ml-2">
                              {new Date(ord.createdAt).toLocaleDateString('es-CO', {
                                day: '2-digit',
                                month: 'short',
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold text-stone-600">Estado:</span>
                            <select
                              value={ord.status}
                              onChange={(e) => onUpdateOrderStatus(ord.id, e.target.value as OrderRecord['status'])}
                              className="text-xs font-bold rounded-lg border border-stone-200 px-2 py-1 bg-stone-50 text-stone-800 focus:outline-none"
                            >
                              <option value="pendiente">Pendiente</option>
                              <option value="en_preparacion">En Preparación</option>
                              <option value="enviado">Enviado</option>
                              <option value="entregado">Entregado</option>
                            </select>
                          </div>
                        </div>

                        {/* Customer details */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-stone-700 bg-stone-50/70 p-3 rounded-xl">
                          <div>
                            <span className="text-stone-400 block text-[10px] uppercase font-bold">Cliente</span>
                            <span className="font-semibold text-stone-900">{ord.customerName}</span>
                          </div>
                          <div>
                            <span className="text-stone-400 block text-[10px] uppercase font-bold">Teléfono / WhatsApp</span>
                            <a
                              href={`https://wa.me/${ord.customerPhone.replace(/\D/g, '')}`}
                              target="_blank"
                              rel="noreferrer"
                              className="font-semibold text-emerald-700 hover:underline flex items-center gap-1"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              <span>{ord.customerPhone}</span>
                            </a>
                          </div>
                          {ord.customerAddress && (
                            <div className="sm:col-span-2">
                              <span className="text-stone-400 block text-[10px] uppercase font-bold">Dirección</span>
                              <span>{ord.customerAddress} {ord.customerCity ? `(${ord.customerCity})` : ''}</span>
                            </div>
                          )}
                          {ord.notes && (
                            <div className="sm:col-span-2 text-stone-500 italic">
                              Nota: &ldquo;{ord.notes}&rdquo;
                            </div>
                          )}
                        </div>

                        {/* Items */}
                        <div className="text-xs space-y-1">
                          <span className="text-[10px] uppercase font-bold text-stone-400 block mb-1">Prendas:</span>
                          {ord.items.map((it, idx) => (
                            <div key={idx} className="flex justify-between text-stone-800">
                              <span>
                                {it.quantity}x {it.productName} {it.size ? `(Talla: ${it.size})` : ''}
                              </span>
                              <span className="font-medium">
                                {formatCurrency(it.price * it.quantity, storeSettings.currencySymbol)}
                              </span>
                            </div>
                          ))}
                        </div>

                        {/* Total Row */}
                        <div className="pt-2 border-t border-stone-100 flex justify-between items-center text-xs">
                          <span className="text-stone-500">Envío: {ord.shipping === 0 ? 'Gratis' : formatCurrency(ord.shipping, storeSettings.currencySymbol)}</span>
                          <div className="text-sm font-bold text-stone-950">
                            Total: <span className="text-rose-900 font-extrabold">{formatCurrency(ord.total, storeSettings.currencySymbol)}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: CUSTOMER INQUIRIES & INSCRIPTIONS */}
            {activeTab === 'inquiries' && (
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-stone-200">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-stone-900 flex items-center gap-2">
                      <MessageCircle className="w-5 h-5 text-violet-600" />
                      <span>Mensajes y Consultas de Clientes ({inquiries.length})</span>
                    </h3>
                    <p className="text-xs text-stone-500">
                      Preguntas sobre ropa, pedidos con inDrive e inscripciones para promociones.
                    </p>
                  </div>

                  {/* Filter Pills */}
                  <div className="flex items-center gap-1.5 bg-stone-100 p-1 rounded-xl">
                    {(['todos', 'nuevo', 'contactado', 'cerrado'] as const).map((st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setInquiryFilter(st)}
                        className={`px-2.5 py-1 text-xs font-semibold rounded-lg capitalize transition-colors cursor-pointer ${
                          inquiryFilter === st
                            ? 'bg-white text-stone-900 shadow-xs'
                            : 'text-stone-500 hover:text-stone-800'
                        }`}
                      >
                        {st}
                        {st === 'nuevo' && inquiries.filter((i) => i.status === 'nuevo').length > 0 && (
                          <span className="ml-1 px-1 bg-rose-500 text-white text-[9px] rounded-full">
                            {inquiries.filter((i) => i.status === 'nuevo').length}
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {inquiries.length === 0 ? (
                  <div className="p-10 text-center bg-stone-50 rounded-3xl border border-stone-200 text-stone-500 space-y-3">
                    <div className="w-12 h-12 bg-stone-200 rounded-full flex items-center justify-center mx-auto text-stone-400">
                      <MessageCircle className="w-6 h-6" />
                    </div>
                    <h4 className="text-sm font-bold text-stone-800">No hay mensajes de clientes aún</h4>
                    <p className="text-xs text-stone-500 max-w-sm mx-auto leading-relaxed">
                      Cuando los visitantes utilicen el botón de contacto para preguntar por una prenda, cotizar carrera de inDrive o inscribirse con el 20% de descuento, sus datos aparecerán aquí para que les escribas directamente.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {inquiries
                      .filter((inq) => inquiryFilter === 'todos' || inq.status === inquiryFilter)
                      .map((inq) => (
                        <div
                          key={inq.id}
                          className={`bg-white border rounded-2xl p-4 sm:p-5 shadow-xs transition-all space-y-3 ${
                            inq.status === 'nuevo'
                              ? 'border-violet-300 ring-1 ring-violet-200 bg-violet-50/20'
                              : 'border-stone-200'
                          }`}
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-stone-100">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-bold text-stone-900 text-sm">{inq.customerName}</span>
                              {inq.customerCity && (
                                <span className="inline-flex items-center gap-1 text-[11px] text-stone-500 bg-stone-100 px-2 py-0.5 rounded-md">
                                  <MapPin className="w-3 h-3 text-stone-400" />
                                  <span>{inq.customerCity}</span>
                                </span>
                              )}
                              <span className="text-[11px] text-stone-400 flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                <span>{new Date(inq.createdAt).toLocaleString('es-NI', { dateStyle: 'short', timeStyle: 'short' })}</span>
                              </span>
                            </div>

                            {/* Status selector badge */}
                            <div className="flex items-center gap-2">
                              <span
                                className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                                  inq.status === 'nuevo'
                                    ? 'bg-rose-100 text-rose-800'
                                    : inq.status === 'contactado'
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-emerald-100 text-emerald-800'
                                }`}
                              >
                                {inq.status}
                              </span>

                              <select
                                value={inq.status}
                                onChange={(e) => handleUpdateInquiryStatus(inq.id, e.target.value as CustomerInquiry['status'])}
                                className="text-xs bg-stone-100 border border-stone-200 rounded-lg px-2 py-1 text-stone-700 focus:outline-none"
                              >
                                <option value="nuevo">Nuevo</option>
                                <option value="contactado">Contactado</option>
                                <option value="cerrado">Cerrado</option>
                              </select>

                              <button
                                type="button"
                                onClick={() => handleDeleteInquiry(inq.id)}
                                className="p-1 text-stone-400 hover:text-red-600 rounded-md transition-colors"
                                title="Eliminar mensaje"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>

                          {/* Inquiry topic badge */}
                          <div className="flex items-center gap-2 text-xs">
                            <span className="text-stone-400 text-[11px] font-bold">Tipo de Consulta:</span>
                            <span className="font-semibold text-violet-900 bg-violet-100/70 px-2.5 py-0.5 rounded-lg text-xs">
                              {inq.inquiryType === 'prenda' && `👗 Prenda: ${inq.productName || 'Consultada'}`}
                              {inq.inquiryType === 'envio_indrive' && '🛵 Envío con inDrive Express'}
                              {inq.inquiryType === 'talla_stock' && '📏 Consulta de Talla / Disponibilidad'}
                              {inq.inquiryType === 'inscripcion_ofertas' && '✨ Inscripción / 20% OFF'}
                              {inq.inquiryType === 'general' && '💬 Pregunta General'}
                            </span>
                          </div>

                          {/* Customer message body */}
                          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/70 text-xs sm:text-sm text-stone-800 font-normal leading-relaxed">
                            &ldquo;{inq.message}&rdquo;
                          </div>

                          {/* Action Buttons */}
                          <div className="pt-2 flex flex-wrap items-center gap-2.5">
                            <button
                              type="button"
                              onClick={() => handleReplyWhatsApp(inq)}
                              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                            >
                              <MessageCircle className="w-4 h-4" />
                              <span>Responder por WhatsApp ({inq.customerPhone})</span>
                            </button>

                            <a
                              href={`tel:${inq.customerPhone}`}
                              className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                            >
                              <Phone className="w-3.5 h-3.5 text-stone-600" />
                              <span>Llamar</span>
                            </a>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: STORE SETTINGS */}
            {activeTab === 'settings' && (
              <div className="flex-1 overflow-y-auto p-4 sm:p-6">
                <form onSubmit={handleSaveSettingsSubmit} className="max-w-xl mx-auto space-y-5">
                  <div>
                    <h3 className="font-serif text-xl font-bold text-stone-900">
                      Configuración de la Tienda
                    </h3>
                    <p className="text-xs text-stone-500 mt-0.5">
                      Personaliza el número de WhatsApp receptor de pedidos, nombre de la marca y costos de envío.
                    </p>
                  </div>

                  {settingsSavedSuccess && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>¡Configuración guardada exitosamente!</span>
                    </div>
                  )}

                  <div className="space-y-4">
                    <div>
                      <label htmlFor={storeNameId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                        Nombre de la Tienda
                      </label>
                      <input
                        id={storeNameId}
                        type="text"
                        value={settingsForm.storeName}
                        onChange={(e) => setSettingsForm({ ...settingsForm, storeName: e.target.value })}
                        className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                      />
                    </div>

                    <div>
                      <label htmlFor={storeTaglineId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                        Slogan / Subtítulo
                      </label>
                      <input
                        id={storeTaglineId}
                        type="text"
                        value={settingsForm.tagline}
                        onChange={(e) => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                        className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                      />
                    </div>

                    {/* WhatsApp Receiver */}
                    <div className="p-3.5 bg-emerald-50/60 border border-emerald-200 rounded-2xl space-y-2">
                      <label htmlFor={storeWhatsappId} className="block text-xs font-bold text-emerald-950 uppercase tracking-wider">
                        📱 Número de WhatsApp para Recibir Pedidos *
                      </label>
                      <input
                        id={storeWhatsappId}
                        type="text"
                        required
                        placeholder="Ej: 573105557890 (con indicativo de país, sin espacios)"
                        value={settingsForm.whatsappNumber}
                        onChange={(e) => setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })}
                        className="w-full px-3 py-2.5 bg-white border border-emerald-300 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-200 font-mono"
                      />
                      <p className="text-[11px] text-emerald-800">
                        Los clientes enviarán el resumen del carrito directamente a este número con un solo clic.
                      </p>
                    </div>

                    <div>
                      <label htmlFor={storeGreetingId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                        Saludo Inicial en Mensaje de WhatsApp
                      </label>
                      <input
                        id={storeGreetingId}
                        type="text"
                        value={settingsForm.whatsappCustomGreeting}
                        onChange={(e) => setSettingsForm({ ...settingsForm, whatsappCustomGreeting: e.target.value })}
                        className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:border-stone-400"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label htmlFor={storeCurrencyId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                          Símbolo Moneda
                        </label>
                        <input
                          id={storeCurrencyId}
                          type="text"
                          value={settingsForm.currencySymbol}
                          onChange={(e) => setSettingsForm({ ...settingsForm, currencySymbol: e.target.value })}
                          className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                        />
                      </div>

                      <div>
                        <label htmlFor={storeShippingCostId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                          Costo de Envío
                        </label>
                        <input
                          id={storeShippingCostId}
                          type="number"
                          value={settingsForm.shippingCost}
                          onChange={(e) => setSettingsForm({ ...settingsForm, shippingCost: Number(e.target.value) })}
                          className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                        />
                      </div>

                      <div>
                        <label htmlFor={storeFreeShippingThresholdId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                          Envío Gratis Desde
                        </label>
                        <input
                          id={storeFreeShippingThresholdId}
                          type="number"
                          value={settingsForm.freeShippingThreshold}
                          onChange={(e) => setSettingsForm({ ...settingsForm, freeShippingThreshold: Number(e.target.value) })}
                          className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                        />
                      </div>
                    </div>

                    {/* inDrive Express Delivery Configuration */}
                    <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">🛵</span>
                          <div>
                            <h4 className="text-xs font-bold text-amber-950 uppercase tracking-wider">
                              Servicio de Entrega inDrive Express
                            </h4>
                            <p className="text-[11px] text-amber-800">
                              Configura el envío con motorizado/conductor inDrive para entregas directas a domicilio.
                            </p>
                          </div>
                        </div>

                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={settingsForm.indriveEnabled !== false}
                            onChange={(e) => setSettingsForm({ ...settingsForm, indriveEnabled: e.target.checked })}
                            className="w-4 h-4 rounded text-amber-600 border-amber-300 focus:ring-amber-500"
                          />
                          <span className="text-xs font-bold text-amber-950">Habilitado</span>
                        </label>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <div>
                          <label className="block text-[11px] font-bold text-amber-950 mb-1">
                            Tarifa Estimada de Carrera ({settingsForm.currencySymbol})
                          </label>
                          <input
                            type="number"
                            min="0"
                            step="5"
                            value={settingsForm.indriveEstimatedCost ?? 70}
                            onChange={(e) => setSettingsForm({ ...settingsForm, indriveEstimatedCost: Number(e.target.value) })}
                            className="w-full px-3 py-2 bg-white border border-amber-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-400 font-mono"
                          />
                          <span className="text-[10px] text-amber-700 mt-0.5 block">
                            Costo referencial sugerido al cliente en el carrito
                          </span>
                        </div>

                        <div>
                          <label className="block text-[11px] font-bold text-amber-950 mb-1">
                            Dirección de Recogida para inDrive
                          </label>
                          <input
                            type="text"
                            value={settingsForm.indrivePickupAddress || ''}
                            onChange={(e) => setSettingsForm({ ...settingsForm, indrivePickupAddress: e.target.value })}
                            placeholder="Ej: Reparto Schick, Managua | Del Cine Ideal 1c al N, 25v O"
                            className="w-full px-3 py-2 bg-white border border-amber-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-400"
                          />
                          <span className="text-[10px] text-amber-700 mt-0.5 block">
                            Punto donde el conductor de inDrive pasará a recoger el paquete
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Datos Bancarios para Pagos y Transferencias */}
                    <div className="p-4 bg-sky-50/70 border border-sky-200 rounded-2xl space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">💳</span>
                        <div>
                          <h4 className="text-xs font-bold text-sky-950 uppercase tracking-wider">
                            Cuenta Bancaria para Transferencias
                          </h4>
                          <p className="text-[11px] text-sky-800">
                            Aparecerá en el carrito y en el resumen de pedido para que los clientes puedan transferirte directamente.
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <div>
                          <label className="block text-[11px] font-bold text-sky-950 mb-1">
                            Banco y Número de Cuenta
                          </label>
                          <input
                            type="text"
                            value={settingsForm.bankAccount || ''}
                            onChange={(e) => setSettingsForm({ ...settingsForm, bankAccount: e.target.value })}
                            placeholder="Ej: LAFISE 131017025"
                            className="w-full px-3 py-2 bg-white border border-sky-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-sky-400 font-mono font-bold"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-bold text-sky-950 mb-1">
                            Titular de la Cuenta
                          </label>
                          <input
                            type="text"
                            value={settingsForm.bankAccountHolder || ''}
                            onChange={(e) => setSettingsForm({ ...settingsForm, bankAccountHolder: e.target.value })}
                            placeholder="Ej: Yordan Isaac Escobar Ruiz"
                            className="w-full px-3 py-2 bg-white border border-sky-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-sky-400 font-semibold"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label htmlFor={storePinId} className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                        PIN de Administrador
                      </label>
                      <input
                        id={storePinId}
                        type="text"
                        maxLength={6}
                        value={settingsForm.adminPin}
                        onChange={(e) => setSettingsForm({ ...settingsForm, adminPin: e.target.value })}
                        className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400 font-mono"
                      />
                    </div>
                  </div>

                  <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row gap-3">
                    <button
                      type="submit"
                      id="btn-save-settings"
                      className="flex-1 py-3 px-4 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl shadow-xs transition-transform active:scale-98"
                    >
                      Guardar Configuración
                    </button>

                    <button
                      type="button"
                      id="btn-reset-factory-products"
                      onClick={() => {
                        if (confirm('¿Deseas restaurar los productos iniciales de muestra de El Clóset de Jiet?')) {
                          onResetProducts();
                        }
                      }}
                      className="py-3 px-4 border border-stone-300 hover:bg-stone-100 text-stone-700 font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Restablecer Prendas de Muestra</span>
                    </button>
                  </div>
                </form>
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
};
