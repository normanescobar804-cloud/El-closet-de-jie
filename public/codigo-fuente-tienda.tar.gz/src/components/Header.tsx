import React from 'react';
import { ShoppingBag, Heart, ShieldCheck, Search, X, Sparkles, User, LogOut, MessageCircle } from 'lucide-react';
import { CurrencyType, StoreSettings, UserAccount } from '../types';
import { formatCurrency } from '../utils/storage';

interface HeaderProps {
  storeSettings: StoreSettings;
  cartCount: number;
  cartTotal: number;
  currency: CurrencyType;
  onCurrencyChange: (curr: CurrencyType) => void;
  favoritesCount: number;
  currentUser: UserAccount | null;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenCart: () => void;
  onOpenFavorites: () => void;
  onOpenAuth: () => void;
  onOpenAdmin: () => void;
  onOpenContact?: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  storeSettings,
  cartCount,
  cartTotal,
  currency,
  onCurrencyChange,
  favoritesCount,
  currentUser,
  searchQuery,
  onSearchChange,
  onOpenCart,
  onOpenFavorites,
  onOpenAuth,
  onOpenAdmin,
  onOpenContact,
  onLogout,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-stone-200/90 transition-shadow duration-200 shadow-2xs">
      {/* 20% Discount & Announcement Top Bar */}
      <div className="bg-gradient-to-r from-violet-700 via-purple-700 to-indigo-800 text-white text-[11px] sm:text-xs py-2 px-3 sm:px-4 text-center font-bold tracking-wide flex items-center justify-center gap-2 flex-wrap shadow-inner">
        <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
        <span>
          🎉 <span className="underline decoration-amber-300">20% DE DESCUENTO</span> EN TODA LA TIENDA
        </span>
        <span className="hidden sm:inline text-white/50">|</span>
        <span className="text-amber-200 hidden sm:inline">
          🚚 Envíos a toda Nicaragua • Pedidos directos a WhatsApp
        </span>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 sm:h-20 gap-2 sm:gap-4">
          
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-2.5">
            <a href="#" className="flex flex-col group">
              <div className="flex items-center gap-1.5">
                <span className="text-xl sm:text-2xl">🛍️</span>
                <span className="font-serif text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-stone-950 group-hover:text-violet-800 transition-colors">
                  {storeSettings.storeName}
                </span>
              </div>
              <span className="text-[9px] sm:text-[11px] tracking-wider uppercase text-stone-500 font-semibold pl-6">
                El closet de jie • Delivery 🛵
              </span>
            </a>
          </div>

          {/* Search Bar - Desktop & Tablet */}
          <div className="hidden md:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                id="search-input-desktop"
                type="text"
                placeholder="Buscar por nombre (ej: vestidos, jeans, blusas)..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-10 pr-9 py-2.5 bg-stone-100 hover:bg-white focus:bg-white text-xs sm:text-sm text-stone-800 rounded-full border border-stone-200 focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-200/50 transition-all placeholder:text-stone-400"
              />
              {searchQuery && (
                <button
                  id="btn-clear-search-desktop"
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-stone-600 rounded-full"
                  title="Limpiar búsqueda"
                  aria-label="Limpiar búsqueda"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Action Buttons & Currency Selector */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            
            {/* Currency Selector (Córdobas / Dólares) */}
            <div className="hidden sm:inline-flex rounded-full bg-stone-100 p-0.5 border border-stone-300/80 text-[11px] font-bold">
              <button
                onClick={() => onCurrencyChange('cordobas')}
                className={`px-2.5 py-1 rounded-full transition-all ${
                  currency === 'cordobas'
                    ? 'bg-violet-600 text-white shadow-2xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
                title="Mostrar precios en Córdobas"
              >
                C$
              </button>
              <button
                onClick={() => onCurrencyChange('dolares')}
                className={`px-2.5 py-1 rounded-full transition-all ${
                  currency === 'dolares'
                    ? 'bg-violet-600 text-white shadow-2xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
                title="Mostrar precios en Dólares"
              >
                $
              </button>
            </div>

            {/* Quick Auth / User profile */}
            {currentUser && currentUser.isLoggedIn ? (
              <div className="relative group hidden sm:flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-full bg-stone-100 border border-stone-200 text-stone-800">
                <div className="w-6 h-6 rounded-full bg-violet-200 text-violet-800 flex items-center justify-center text-xs font-bold">
                  {currentUser.name.charAt(0).toUpperCase()}
                </div>
                <span className="text-xs font-semibold max-w-[90px] truncate">
                  {currentUser.name.split(' ')[0]}
                </span>
                <button
                  id="btn-logout-header"
                  onClick={onLogout}
                  title="Cerrar sesión"
                  className="text-stone-400 hover:text-red-600 transition-colors ml-1 p-0.5"
                  aria-label="Cerrar sesión"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                id="btn-open-auth-header"
                onClick={onOpenAuth}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-700 hover:text-stone-900 hover:bg-stone-100 rounded-full border border-stone-200 transition-colors"
              >
                <User className="w-4 h-4 text-stone-500" />
                <span>Ingresar</span>
              </button>
            )}

            {/* Contact / Inscription Button */}
            {onOpenContact && (
              <button
                id="btn-open-contact-header"
                onClick={onOpenContact}
                className="hidden md:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100 rounded-full border border-violet-200 transition-colors cursor-pointer"
                title="Enviar mensaje / Contactar al dueño"
              >
                <MessageCircle className="w-3.5 h-3.5 text-violet-600" />
                <span>Contacto</span>
              </button>
            )}

            {/* Favorites Button */}
            <button
              id="btn-open-favorites-header"
              onClick={onOpenFavorites}
              className="relative p-2 sm:p-2.5 text-stone-700 hover:text-rose-600 hover:bg-rose-50/50 rounded-full transition-colors flex items-center justify-center"
              title="Mis Favoritos"
              aria-label="Favoritos"
            >
              <Heart className={`w-5 h-5 ${favoritesCount > 0 ? 'fill-rose-500 text-rose-500' : ''}`} />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* Cart Button */}
            <button
              id="btn-open-cart-header"
              onClick={onOpenCart}
              className="relative flex items-center gap-2 bg-gradient-to-r from-violet-600 to-indigo-700 hover:from-violet-700 hover:to-indigo-800 active:scale-95 text-white px-3 py-2 sm:px-4 sm:py-2.5 rounded-full transition-all shadow-md cursor-pointer"
              title="Ver Carrito de Compras"
              aria-label="Carrito de compras"
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5 text-amber-200" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-rose-500 text-white text-[10px] font-black w-4 h-4 sm:w-5 sm:h-5 rounded-full flex items-center justify-center shadow-xs animate-bounce">
                    {cartCount}
                  </span>
                )}
              </div>
              <div className="hidden lg:flex flex-col text-left leading-tight">
                <span className="text-[10px] uppercase font-bold text-violet-200">Carrito</span>
                <span className="text-xs font-black text-white">
                  {cartCount > 0 ? formatCurrency(cartTotal, currency, storeSettings.exchangeRate) : 'Vacío'}
                </span>
              </div>
            </button>

            {/* Admin Panel Toggle */}
            <button
              id="btn-open-admin-header"
              onClick={onOpenAdmin}
              className="p-2 sm:p-2.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-full transition-colors flex items-center justify-center"
              title="Panel de Administrador"
              aria-label="Administrador"
            >
              <ShieldCheck className="w-5 h-5" />
            </button>

          </div>
        </div>

        {/* Mobile Search Bar + Mobile Currency Switcher */}
        <div className="pb-2.5 pt-1 md:hidden flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              id="search-input-mobile"
              type="text"
              placeholder="Buscar camisetas, jeans, vestidos..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-stone-100 text-xs text-stone-800 rounded-full border border-stone-200 focus:border-violet-400 focus:outline-none"
            />
            {searchQuery && (
              <button
                id="btn-clear-search-mobile"
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-stone-400"
                aria-label="Limpiar búsqueda"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="inline-flex rounded-full bg-stone-100 p-0.5 border border-stone-300 text-[11px] font-bold shrink-0">
            <button
              onClick={() => onCurrencyChange('cordobas')}
              className={`px-2 py-1 rounded-full transition-all ${
                currency === 'cordobas' ? 'bg-violet-600 text-white' : 'text-stone-600'
              }`}
            >
              C$
            </button>
            <button
              onClick={() => onCurrencyChange('dolares')}
              className={`px-2 py-1 rounded-full transition-all ${
                currency === 'dolares' ? 'bg-violet-600 text-white' : 'text-stone-600'
              }`}
            >
              $
            </button>
          </div>
        </div>

      </div>
    </header>
  );
};
