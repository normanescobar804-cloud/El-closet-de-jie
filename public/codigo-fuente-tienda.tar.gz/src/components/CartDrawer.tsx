import React, { useState, useId } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, MessageCircle, ArrowRight, Truck, CheckCircle2, Navigation, MapPin, Star, Check } from 'lucide-react';
import { CartItem, CurrencyType, DeliveryMethod, OrderRecord, ProductReview, StoreSettings, UserAccount } from '../types';
import { formatCurrency, saveOrder, saveReview } from '../utils/storage';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  currency: CurrencyType;
  onCurrencyChange: (curr: CurrencyType) => void;
  storeSettings: StoreSettings;
  currentUser: UserAccount | null;
  onUpdateQuantity: (itemId: string, newQty: number) => void;
  onRemoveItem: (itemId: string) => void;
  onClearCart: () => void;
  onOrderCompleted?: (order: OrderRecord) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  currency,
  onCurrencyChange,
  storeSettings,
  currentUser,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOrderCompleted,
}) => {
  const nameInputId = useId();
  const phoneInputId = useId();
  const addressInputId = useId();
  const notesInputId = useId();
  const indriveRefInputId = useId();
  const indriveMapInputId = useId();

  // Customer checkout form
  const [customerName, setCustomerName] = useState(currentUser?.name || '');
  const [customerPhone, setCustomerPhone] = useState(currentUser?.phoneOrEmail || '');
  const [customerAddress, setCustomerAddress] = useState(currentUser?.address || '');
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod>(
    storeSettings.indriveEnabled !== false ? 'indrive' : 'departamental'
  );
  const [indriveReference, setIndriveReference] = useState('');
  const [indriveLocationUrl, setIndriveLocationUrl] = useState('');
  const [orderNotes, setOrderNotes] = useState('');
  const [showCheckoutForm, setShowCheckoutForm] = useState(false);
  const [formError, setFormError] = useState('');

  // ⭐ Post-Purchase 5-Star Rating State
  const [completedOrder, setCompletedOrder] = useState<OrderRecord | null>(null);
  const [itemRatings, setItemRatings] = useState<
    Record<string, { stars: number; comment: string; submitted: boolean }>
  >({});

  const handleRatePurchasedItem = (productId: string) => {
    const current = itemRatings[productId];
    if (!current) return;

    const newReview: ProductReview = {
      id: `rev-post-purchase-${Date.now()}-${productId}`,
      productId: productId,
      customerName: customerName.trim() || 'Cliente Verificado',
      rating: current.stars,
      comment: current.comment.trim() || `¡Excelente compra en El closet de jie! Calificación: ${current.stars} estrellas.`,
      verifiedPurchase: true,
      createdAt: new Date().toLocaleDateString('es-NI', { year: 'numeric', month: 'short', day: 'numeric' })
    };

    saveReview(newReview);
    setItemRatings(prev => ({
      ...prev,
      [productId]: { ...prev[productId], submitted: true }
    }));
  };

  const handleCloseAfterCompleted = () => {
    setCompletedOrder(null);
    setItemRatings({});
    setShowCheckoutForm(false);
    onClose();
  };

  if (!isOpen) return null;

  // 💰 Automatic Calculations (Base in Córdobas)
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  
  // 20% discount on all items in the store (like user's website)
  const discountPercent = storeSettings.discountPercent ?? 20;
  const discountAmount = Math.round((subtotal * discountPercent) / 100);
  const subtotalAfterDiscount = Math.max(0, subtotal - discountAmount);

  // Shipping cost based on selected method
  const isFreeShipping = subtotalAfterDiscount >= (storeSettings.freeShippingThreshold || 450);
  let shipping = 0;
  if (cart.length > 0) {
    if (deliveryMethod === 'pickup') {
      shipping = 0;
    } else if (deliveryMethod === 'indrive') {
      shipping = isFreeShipping ? 0 : (storeSettings.indriveEstimatedCost || 70);
    } else {
      // departamental
      shipping = isFreeShipping ? 0 : (storeSettings.shippingCost || 120);
    }
  }
  
  // Final Total
  const total = subtotalAfterDiscount + shipping;

  const freeShippingDifference = Math.max(0, (storeSettings.freeShippingThreshold || 450) - subtotalAfterDiscount);
  const freeShippingProgress = Math.min(
    100,
    Math.round((subtotalAfterDiscount / (storeSettings.freeShippingThreshold || 450)) * 100)
  );

  // 📱 Send WhatsApp Order
  const handleCheckoutWhatsApp = () => {
    setFormError('');

    if (cart.length === 0) {
      setFormError('El carrito está vacío. Agrega productos para ordenar.');
      return;
    }

    if (!customerName.trim()) {
      setShowCheckoutForm(true);
      setFormError('Por favor ingresa tu nombre para identificar tu pedido.');
      return;
    }

    if (!customerPhone.trim()) {
      setShowCheckoutForm(true);
      setFormError('Por favor ingresa tu número de WhatsApp para contacto.');
      return;
    }

    if (deliveryMethod === 'indrive' && !customerAddress.trim() && !indriveReference.trim()) {
      setShowCheckoutForm(true);
      setFormError('Para entrega por inDrive, indica tu dirección o un punto de referencia para el conductor.');
      return;
    }

    // Format WhatsApp message
    let orderMessage = `*¡Hola ${storeSettings.storeName}!* 🛍️✨\n`;
    orderMessage += `Me gustaría realizar el siguiente pedido desde su tienda online:\n\n`;
    orderMessage += `📋 *PRODUCTOS SELECCIONADOS:*\n`;

    cart.forEach((item, index) => {
      const itemSubtotal = item.product.price * item.quantity;
      const sizeText = item.selectedSize ? ` (Talla: ${item.selectedSize})` : '';
      const colorText = item.selectedColor ? ` [Color: ${item.selectedColor}]` : '';
      orderMessage += `${index + 1}. *${item.product.name}* ${item.product.icon || ''}\n`;
      orderMessage += `   • Cantidad: ${item.quantity}${sizeText}${colorText}\n`;
      orderMessage += `   • Precio: ${formatCurrency(item.product.price, currency, storeSettings.exchangeRate)} c/u\n`;
      orderMessage += `   • Subtotal: ${formatCurrency(itemSubtotal, currency, storeSettings.exchangeRate)}\n`;
    });

    orderMessage += `\n─────────────────────\n`;
    orderMessage += `💵 *Subtotal:* ${formatCurrency(subtotal, currency, storeSettings.exchangeRate)}\n`;
    if (discountAmount > 0) {
      orderMessage += `🏷️ *Descuento (${discountPercent}%):* -${formatCurrency(discountAmount, currency, storeSettings.exchangeRate)}\n`;
    }

    let shippingLabel = '';
    if (deliveryMethod === 'indrive') {
      shippingLabel = isFreeShipping ? 'inDrive GRATIS 🎉' : `inDrive (${formatCurrency(shipping, currency, storeSettings.exchangeRate)})`;
    } else if (deliveryMethod === 'departamental') {
      shippingLabel = isFreeShipping ? 'Departamental GRATIS 🎉' : `Departamental (${formatCurrency(shipping, currency, storeSettings.exchangeRate)})`;
    } else {
      shippingLabel = 'Retiro en Tienda (Gratis)';
    }

    orderMessage += `🚚 *Envío:* ${shippingLabel}\n`;
    orderMessage += `⭐ *TOTAL A PAGAR:* ${formatCurrency(total, currency, storeSettings.exchangeRate)}\n`;
    if (currency === 'dolares') {
      orderMessage += `   (Equivalente en Córdobas: C$ ${total.toFixed(2)})\n`;
    }
    orderMessage += `─────────────────────\n\n`;

    orderMessage += `📍 *DATOS PARA LA ENTREGA:*\n`;
    orderMessage += `👤 *Cliente:* ${customerName.trim()}\n`;
    orderMessage += `📱 *Teléfono:* ${customerPhone.trim()}\n`;

    if (deliveryMethod === 'indrive') {
      orderMessage += `🛵 *MÉTODO DE ENVÍO:* inDrive Express (Entrega inmediata hasta el lugar)\n`;
      if (customerAddress.trim()) {
        orderMessage += `🏡 *Dirección de destino:* ${customerAddress.trim()}\n`;
      }
      if (indriveReference.trim()) {
        orderMessage += `🧭 *Punto de referencia para conductor:* ${indriveReference.trim()}\n`;
      }
      if (indriveLocationUrl.trim()) {
        orderMessage += `🗺️ *Ubicación / GPS:* ${indriveLocationUrl.trim()}\n`;
      }
    } else if (deliveryMethod === 'departamental') {
      orderMessage += `📦 *MÉTODO DE ENVÍO:* Envío Departamental (CargoTrans / Mensajería)\n`;
      if (customerAddress.trim()) {
        orderMessage += `🏡 *Dirección de envío:* ${customerAddress.trim()}\n`;
      }
    } else {
      orderMessage += `🛍️ *MÉTODO DE ENTREGA:* Retiro personal en tienda física (Reparto Chick)\n`;
    }

    if (orderNotes.trim()) {
      orderMessage += `📝 *Notas adicionales:* ${orderNotes.trim()}\n`;
    }
    if (storeSettings.bankAccount) {
      orderMessage += `💳 *Cuenta para transferir:* ${storeSettings.bankAccount}\n`;
      if (storeSettings.bankAccountHolder) {
        orderMessage += `👤 *Titular:* ${storeSettings.bankAccountHolder}\n`;
      }
    }

    orderMessage += `\n¿Me confirman disponibilidad de las prendas para coordinar la entrega? ¡Muchas gracias! 🙏`;

    // Save record to order history
    const orderRecord: OrderRecord = {
      id: `JIET-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString(),
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerAddress: customerAddress.trim(),
      deliveryMethod,
      indriveReference: indriveReference.trim() || undefined,
      indriveLocationUrl: indriveLocationUrl.trim() || undefined,
      notes: orderNotes.trim(),
      items: cart.map(i => ({
        productId: i.product.id,
        productName: i.product.name,
        price: i.product.price,
        quantity: i.quantity,
        size: i.selectedSize,
        color: i.selectedColor
      })),
      subtotal,
      discount: discountAmount,
      shipping,
      total,
      currency,
      status: 'pendiente'
    };

    saveOrder(orderRecord);
    if (onOrderCompleted) onOrderCompleted(orderRecord);

    // Initialize ratings for each product in the order
    const initialRatings: Record<string, { stars: number; comment: string; submitted: boolean }> = {};
    orderRecord.items.forEach(it => {
      initialRatings[it.productId] = { stars: 5, comment: '', submitted: false };
    });
    setItemRatings(initialRatings);
    setCompletedOrder(orderRecord);
    onClearCart();

    // Clean phone number: if local 8-digit Nicaraguan phone like 83702337, prepend 505
    let rawNumber = storeSettings.whatsappNumber.replace(/\D/g, '');
    if (rawNumber.length === 8) {
      rawNumber = `505${rawNumber}`;
    }
    if (!rawNumber) {
      rawNumber = '50583702337';
    }

    const whatsappUrl = `https://wa.me/${rawNumber}?text=${encodeURIComponent(orderMessage)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-md bg-white shadow-2xl flex flex-col h-full border-l border-stone-200 z-10 animate-slide-left">
        
        {completedOrder ? (
          /* ⭐ Post-Purchase 5-Star Rating & Confirmation Screen */
          <div className="flex flex-col h-full overflow-hidden bg-stone-50">
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-stone-200 bg-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-base">
                  ✓
                </div>
                <div>
                  <h2 className="font-serif text-lg font-bold text-stone-900 leading-tight">
                    ¡Pedido Confirmado!
                  </h2>
                  <p className="text-[11px] text-emerald-700 font-semibold">
                    Enviado a WhatsApp ({storeSettings.whatsappNumber})
                  </p>
                </div>
              </div>
              <button
                onClick={handleCloseAfterCompleted}
                className="w-8 h-8 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-100 flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
              {/* Bank & Payment Info Reminder */}
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-stone-700 space-y-1.5">
                <p className="font-bold text-emerald-950 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  Total de la orden: {formatCurrency(completedOrder.total, currency, storeSettings.exchangeRate)}
                </p>
                <p className="text-[11px] text-emerald-900">
                  Banco LAFISE: <span className="font-bold font-mono text-emerald-950">131017025</span> (Yordan Isaac Escobar Ruiz)
                </p>
                <p className="text-[11px] text-stone-600">
                  Envíos y entregas coordinadas por delivery 🛵
                </p>
              </div>

              {/* 5-Star Rating Prompt Box */}
              <div className="p-4 bg-white border border-amber-200 rounded-2xl shadow-xs space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xl">⭐</span>
                  <div>
                    <h3 className="text-sm font-black text-stone-900 leading-snug">
                      ¿Cuántas estrellas le das al producto después de comprarlo?
                    </h3>
                    <p className="text-[11px] text-stone-500">
                      Deja tu calificación para que todos los clientes vean cuántas estrellas le das a cada prenda:
                    </p>
                  </div>
                </div>

                {/* List of purchased items to rate */}
                <div className="space-y-3 pt-2">
                  {completedOrder.items.map((item) => {
                    const ratingState = itemRatings[item.productId] || { stars: 5, comment: '', submitted: false };

                    return (
                      <div
                        key={item.productId}
                        className={`p-3.5 rounded-xl border transition-all ${
                          ratingState.submitted
                            ? 'bg-emerald-50/70 border-emerald-200'
                            : 'bg-stone-50 border-stone-200'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div>
                            <h4 className="font-bold text-xs text-stone-900">
                              {item.productName}
                            </h4>
                            <p className="text-[11px] text-stone-500">
                              {item.size ? `Talla: ${item.size}` : ''} {item.color ? `• Color: ${item.color}` : ''}
                            </p>
                          </div>
                          <span className="text-xs font-black text-violet-900">
                            {formatCurrency(item.price * item.quantity, currency, storeSettings.exchangeRate)}
                          </span>
                        </div>

                        {/* Interactive 5 Stars */}
                        <div className="space-y-1.5 pt-1">
                          <div className="flex items-center gap-1">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                key={star}
                                type="button"
                                disabled={ratingState.submitted}
                                onClick={() => {
                                  setItemRatings(prev => ({
                                    ...prev,
                                    [item.productId]: {
                                      ...prev[item.productId],
                                      stars: star
                                    }
                                  }));
                                }}
                                className={`p-1 transition-transform ${
                                  ratingState.submitted ? 'cursor-default' : 'hover:scale-125 cursor-pointer'
                                }`}
                              >
                                <Star
                                  className={`w-6 h-6 transition-colors ${
                                    star <= ratingState.stars
                                      ? 'fill-amber-400 text-amber-400'
                                      : 'text-stone-300'
                                  }`}
                                />
                              </button>
                            ))}
                          </div>

                          <div className="text-[11px] font-bold text-amber-900">
                            {ratingState.stars === 5 && '⭐⭐⭐⭐⭐ ¡Le diste 5 Estrellas (Excelente!)'}
                            {ratingState.stars === 4 && '⭐⭐⭐⭐ ¡Le diste 4 Estrellas (Muy Buena!)'}
                            {ratingState.stars === 3 && '⭐⭐⭐ Le diste 3 Estrellas (Buena)'}
                            {ratingState.stars === 2 && '⭐⭐ Le diste 2 Estrellas (Regular)'}
                            {ratingState.stars === 1 && '⭐ Le diste 1 Estrella'}
                          </div>

                          {!ratingState.submitted && (
                            <div className="space-y-2 pt-2">
                              <input
                                type="text"
                                value={ratingState.comment}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setItemRatings(prev => ({
                                    ...prev,
                                    [item.productId]: {
                                      ...prev[item.productId],
                                      comment: val
                                    }
                                  }));
                                }}
                                placeholder="Escribe tu opinión opcional (ej: muy bonita prenda)"
                                className="w-full px-3 py-1.5 text-xs bg-white border border-stone-200 rounded-lg text-stone-900 focus:outline-none focus:ring-1 focus:ring-violet-400"
                              />

                              <button
                                type="button"
                                onClick={() => handleRatePurchasedItem(item.productId)}
                                className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 font-black text-xs rounded-lg flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                              >
                                <Star className="w-3.5 h-3.5 fill-current" />
                                <span>Guardar Calificación de {ratingState.stars} Estrellas</span>
                              </button>
                            </div>
                          )}

                          {ratingState.submitted && (
                            <div className="text-[11px] font-bold text-emerald-800 flex items-center gap-1.5 pt-1">
                              <Check className="w-4 h-4 text-emerald-600" />
                              <span>✓ ¡Tu calificación de {ratingState.stars} estrellas se publicó para todos los clientes!</span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Footer Button */}
            <div className="p-4 bg-white border-t border-stone-200 shrink-0">
              <button
                onClick={handleCloseAfterCompleted}
                className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white font-bold text-sm rounded-xl transition-colors shadow-xs cursor-pointer"
              >
                Volver al Catálogo y Seguir Comprando
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-stone-100 flex items-center justify-between bg-stone-50/80 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-violet-100 text-violet-700 flex items-center justify-center font-bold">
                  🛒
                </div>
                <div>
                  <h2 className="font-serif text-lg font-bold text-stone-900 leading-tight">
                    Mi Carrito de Compras
                  </h2>
                  <p className="text-[11px] text-stone-500">
                    {cart.reduce((sum, i) => sum + i.quantity, 0)} prenda{cart.reduce((sum, i) => sum + i.quantity, 0) !== 1 ? 's' : ''} en total
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {cart.length > 0 && (
                  <button
                    id="btn-clear-cart"
                    onClick={onClearCart}
                    className="text-xs text-stone-400 hover:text-red-600 transition-colors font-semibold px-2 py-1"
                    title="Vaciar carrito"
                  >
                    Vaciar
                  </button>
                )}
                <button
                  id="btn-close-cart-drawer"
                  onClick={onClose}
                  className="w-9 h-9 rounded-full text-stone-500 hover:text-stone-900 hover:bg-stone-200/70 flex items-center justify-center transition-colors"
                  aria-label="Cerrar carrito"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

        {/* Currency Switcher Toggle (Córdobas C$ / Dólares $) */}
        <div className="px-4 py-2 bg-stone-100/70 border-b border-stone-200 flex items-center justify-between gap-2 shrink-0">
          <span className="text-[11px] font-semibold text-stone-600">Moneda de pago:</span>
          <div className="inline-flex rounded-full bg-stone-200/80 p-0.5 border border-stone-300">
            <button
              id="btn-currency-cordobas"
              onClick={() => onCurrencyChange('cordobas')}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                currency === 'cordobas'
                  ? 'bg-violet-600 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Córdobas (C$)
            </button>
            <button
              id="btn-currency-dolares"
              onClick={() => onCurrencyChange('dolares')}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                currency === 'dolares'
                  ? 'bg-violet-600 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Dólares ($)
            </button>
          </div>
        </div>

        {/* 20% Discount Banner in Cart */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white px-4 py-2 text-center text-xs font-bold tracking-wide flex items-center justify-center gap-1.5 shadow-2xs shrink-0">
          <span>✨ 20% DE DESCUENTO AUTOMÁTICO APLICADO ✨</span>
        </div>

        {/* Free Shipping Alert */}
        {cart.length > 0 && (
          <div className="bg-amber-50 px-4 py-2 border-b border-amber-100 text-xs text-amber-900 shrink-0">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-1.5 font-medium">
                <Truck className="w-3.5 h-3.5 text-amber-700" />
                <span>
                  {isFreeShipping ? (
                    <span className="text-emerald-800 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      ¡Envío GRATIS alcanzado!
                    </span>
                  ) : (
                    <>
                      Faltan <strong className="text-amber-950 font-bold">{formatCurrency(freeShippingDifference, currency, storeSettings.exchangeRate)}</strong> para Envío GRATIS
                    </>
                  )}
                </span>
              </div>
              <span className="text-[10px] font-bold text-amber-800">{freeShippingProgress}%</span>
            </div>
            <div className="w-full bg-amber-200/80 h-1.5 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  isFreeShipping ? 'bg-emerald-500' : 'bg-amber-600'
                }`}
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Scrollable Items List */}
        <div className="flex-1 overflow-y-auto p-4 divide-y divide-stone-100 space-y-2">
          {cart.length === 0 ? (
            <div className="h-full min-h-[260px] flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-20 h-20 rounded-full bg-violet-50 text-violet-400 flex items-center justify-center text-3xl">
                🛍️
              </div>
              <div>
                <h3 className="font-serif text-lg font-bold text-stone-900 mb-1">
                  Tu carrito está vacío 😢
                </h3>
                <p className="text-xs text-stone-500 max-w-xs mx-auto">
                  Agrega prendas con descuento del catálogo de {storeSettings.storeName} para iniciar tu pedido.
                </p>
              </div>
              <button
                id="btn-empty-cart-explore"
                onClick={onClose}
                className="mt-2 bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold px-6 py-3 rounded-full transition-transform active:scale-95 shadow-md"
              >
                Ver Catálogo de Ropa
              </button>
            </div>
          ) : (
            <div className="space-y-3 pt-1">
              {cart.map((item) => {
                const itemTotal = item.product.price * item.quantity;
                return (
                  <div
                    key={item.id}
                    className="flex gap-3 pt-3 first:pt-0 group items-center bg-stone-50/50 p-2.5 rounded-xl border border-stone-100"
                  >
                    {/* Thumbnail / Icon */}
                    <div className="w-16 h-18 rounded-lg overflow-hidden bg-white shrink-0 border border-stone-200 flex items-center justify-center relative">
                      {item.product.images && item.product.images[0] ? (
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-2xl">{item.product.icon || '👕'}</span>
                      )}
                      {item.product.icon && (
                        <span className="absolute bottom-0.5 right-0.5 text-xs bg-white/90 rounded px-1 shadow-2xs">
                          {item.product.icon}
                        </span>
                      )}
                    </div>

                    {/* Item Info */}
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div className="flex justify-between items-start gap-1">
                        <div>
                          <h4 className="font-bold text-xs sm:text-sm text-stone-900 line-clamp-1">
                            {item.product.name}
                          </h4>
                          {item.selectedSize && item.selectedSize !== 'Única' && (
                            <span className="inline-block text-[10px] text-stone-500 font-medium">
                              Talla: {item.selectedSize}
                            </span>
                          )}
                        </div>

                        {/* 🗑️ Remove Button */}
                        <button
                          id={`btn-remove-item-${item.id}`}
                          onClick={() => onRemoveItem(item.id)}
                          className="text-stone-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-red-50 transition-colors"
                          title="Eliminar producto"
                          aria-label="Eliminar producto"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* ➕➖ Quantity & Price Row */}
                      <div className="flex items-center justify-between mt-2.5">
                        <div className="flex items-center border border-stone-300 rounded-lg bg-white overflow-hidden shadow-2xs">
                          <button
                            id={`btn-cart-minus-${item.id}`}
                            onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                            className="w-8 h-8 flex items-center justify-center text-stone-700 hover:bg-stone-100 active:bg-stone-200 transition-colors"
                            title="Disminuir cantidad"
                            aria-label="Disminuir cantidad"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="w-8 text-center text-xs font-bold text-stone-900 select-none">
                            {item.quantity}
                          </span>
                          <button
                            id={`btn-cart-plus-${item.id}`}
                            onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                            className="w-8 h-8 flex items-center justify-center text-stone-700 hover:bg-stone-100 active:bg-stone-200 transition-colors"
                            title="Aumentar cantidad"
                            aria-label="Aumentar cantidad"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="text-right">
                          <div className="text-xs font-bold text-stone-900">
                            {formatCurrency(itemTotal, currency, storeSettings.exchangeRate)}
                          </div>
                          {item.quantity > 1 && (
                            <div className="text-[10px] text-stone-400">
                              {formatCurrency(item.product.price, currency, storeSettings.exchangeRate)} c/u
                            </div>
                          )}
                        </div>
                      </div>

                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Bottom Checkout & Summary Footer */}
        {cart.length > 0 && (
          <div className="p-4 bg-white border-t border-stone-200 shadow-xl space-y-3 shrink-0">
            
            {/* Customer Details Form Collapsible */}
            <div className="border border-stone-200 rounded-xl overflow-hidden bg-stone-50/70">
              <button
                type="button"
                onClick={() => setShowCheckoutForm(!showCheckoutForm)}
                className="w-full px-3 py-2 text-xs font-bold text-stone-800 flex items-center justify-between hover:bg-stone-100 transition-colors"
              >
                <span className="flex items-center gap-1.5">
                  <span>📍 Datos de entrega {customerName ? `(${customerName})` : ''}</span>
                </span>
                <span className="text-[11px] text-violet-700 underline font-semibold">
                  {showCheckoutForm ? 'Ocultar' : 'Completar datos'}
                </span>
              </button>

              {showCheckoutForm && (
                <div className="p-3 border-t border-stone-200 bg-white space-y-3 text-xs">
                  {/* Delivery Method Selection */}
                  <div>
                    <label className="block text-[11px] font-bold text-stone-800 mb-1.5">
                      Método de Entrega / Envío *
                    </label>
                    <div className="grid grid-cols-1 gap-1.5">
                      {/* inDrive Option */}
                      <button
                        type="button"
                        onClick={() => setDeliveryMethod('indrive')}
                        className={`p-2 rounded-xl border text-left flex items-start justify-between transition-all cursor-pointer ${
                          deliveryMethod === 'indrive'
                            ? 'bg-amber-50/80 border-amber-500 ring-2 ring-amber-300'
                            : 'bg-stone-50 border-stone-200 hover:bg-stone-100'
                        }`}
                      >
                        <div className="flex items-start gap-2">
                          <span className="text-lg leading-none">🛵</span>
                          <div>
                            <div className="font-bold text-stone-900 flex items-center gap-1.5">
                              <span>Envío por inDrive Express</span>
                              <span className="bg-amber-200 text-amber-950 text-[9px] font-extrabold px-1.5 py-0.2 rounded uppercase">
                                Rápido
                              </span>
                            </div>
                            <p className="text-[10px] text-stone-500 mt-0.5">
                              Un conductor de inDrive lleva el paquete a tu puerta hoy mismo en Managua
                            </p>
                          </div>
                        </div>
                        <span className="font-bold text-stone-800 text-[11px] shrink-0">
                          {isFreeShipping ? 'GRATIS' : formatCurrency(storeSettings.indriveEstimatedCost || 70, currency, storeSettings.exchangeRate)}
                        </span>
                      </button>

                      {/* Departamental */}
                      <button
                        type="button"
                        onClick={() => setDeliveryMethod('departamental')}
                        className={`p-2 rounded-xl border text-left flex items-start justify-between transition-all cursor-pointer ${
                          deliveryMethod === 'departamental'
                            ? 'bg-violet-50/80 border-violet-500 ring-2 ring-violet-300'
                            : 'bg-stone-50 border-stone-200 hover:bg-stone-100'
                        }`}
                      >
                        <div className="flex items-start gap-2">
                          <span className="text-lg leading-none">📦</span>
                          <div>
                            <div className="font-bold text-stone-900">
                              Envío Departamental (Nacional)
                            </div>
                            <p className="text-[10px] text-stone-500 mt-0.5">
                              Envíos a León, Matagalpa, Estelí, etc. (CargoTrans / Mensajería)
                            </p>
                          </div>
                        </div>
                        <span className="font-bold text-stone-800 text-[11px] shrink-0">
                          {isFreeShipping ? 'GRATIS' : formatCurrency(storeSettings.shippingCost || 120, currency, storeSettings.exchangeRate)}
                        </span>
                      </button>

                      {/* Pickup */}
                      <button
                        type="button"
                        onClick={() => setDeliveryMethod('pickup')}
                        className={`p-2 rounded-xl border text-left flex items-start justify-between transition-all cursor-pointer ${
                          deliveryMethod === 'pickup'
                            ? 'bg-emerald-50/80 border-emerald-500 ring-2 ring-emerald-300'
                            : 'bg-stone-50 border-stone-200 hover:bg-stone-100'
                        }`}
                      >
                        <div className="flex items-start gap-2">
                          <span className="text-lg leading-none">🛍️</span>
                          <div>
                            <div className="font-bold text-stone-900">
                              Retiro en Tienda Física
                            </div>
                            <p className="text-[10px] text-stone-500 mt-0.5">
                              Reparto Chick, del Cine Ideal 1c al norte, 25 varas oeste
                            </p>
                          </div>
                        </div>
                        <span className="font-bold text-emerald-700 text-[11px] shrink-0">
                          Gratis
                        </span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <label htmlFor={nameInputId} className="block text-[11px] font-bold text-stone-700 mb-0.5">
                      Nombre y Apellido *
                    </label>
                    <input
                      id={nameInputId}
                      type="text"
                      placeholder="Ej: María José López"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-2.5 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:border-violet-500"
                    />
                  </div>

                  <div>
                    <label htmlFor={phoneInputId} className="block text-[11px] font-bold text-stone-700 mb-0.5">
                      Número de WhatsApp *
                    </label>
                    <input
                      id={phoneInputId}
                      type="tel"
                      placeholder="Ej: 83702337"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full px-2.5 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:border-violet-500"
                    />
                  </div>

                  {deliveryMethod !== 'pickup' && (
                    <div>
                      <label htmlFor={addressInputId} className="block text-[11px] font-bold text-stone-700 mb-0.5">
                        {deliveryMethod === 'indrive' ? 'Dirección o Barrio en Managua *' : 'Dirección y Departamento *'}
                      </label>
                      <input
                        id={addressInputId}
                        type="text"
                        placeholder={deliveryMethod === 'indrive' ? 'Ej: Bello Horizonte, Col. Centroamérica, etc.' : 'Ej: León, del parque central 2c al sur'}
                        value={customerAddress}
                        onChange={(e) => setCustomerAddress(e.target.value)}
                        className="w-full px-2.5 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:border-violet-500"
                      />
                    </div>
                  )}

                  {/* inDrive specific fields */}
                  {deliveryMethod === 'indrive' && (
                    <div className="bg-amber-50/70 p-2.5 rounded-xl border border-amber-200 space-y-2">
                      <div>
                        <label htmlFor={indriveRefInputId} className="block text-[10px] font-bold text-amber-950 mb-0.5">
                          🧭 Punto de referencia exacto para el conductor de inDrive *
                        </label>
                        <input
                          id={indriveRefInputId}
                          type="text"
                          placeholder="Ej: Del portón del colegio 2c abajo, casa esquinera color crema con verjas negras"
                          value={indriveReference}
                          onChange={(e) => setIndriveReference(e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      <div>
                        <label htmlFor={indriveMapInputId} className="block text-[10px] font-bold text-amber-950 mb-0.5">
                          🗺️ Enlace de Ubicación / Google Maps (Opcional)
                        </label>
                        <input
                          id={indriveMapInputId}
                          type="url"
                          placeholder="Pega el enlace de Google Maps o WhatsApp de tu ubicación"
                          value={indriveLocationUrl}
                          onChange={(e) => setIndriveLocationUrl(e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:border-amber-500"
                        />
                      </div>
                      <p className="text-[10px] text-amber-800 leading-tight">
                        📍 Recogida desde la tienda: <span className="font-semibold">{storeSettings.indrivePickupAddress}</span>.
                      </p>
                    </div>
                  )}

                  <div>
                    <label htmlFor={notesInputId} className="block text-[11px] font-bold text-stone-700 mb-0.5">
                      Notas o instrucciones (Opcional)
                    </label>
                    <input
                      id={notesInputId}
                      type="text"
                      placeholder="Ej: Entregar después de las 3pm, tocar timbre"
                      value={orderNotes}
                      onChange={(e) => setOrderNotes(e.target.value)}
                      className="w-full px-2.5 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:border-violet-500"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Form Validation Alert */}
            {formError && (
              <div className="text-xs text-red-700 bg-red-50 p-2 rounded-lg border border-red-200 font-semibold">
                ⚠️ {formError}
              </div>
            )}

            {/* 💰 Subtotal & Total Breakdown */}
            <div className="space-y-1.5 text-xs text-stone-600 bg-stone-50 p-3 rounded-xl border border-stone-200">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span className="font-bold text-stone-800">
                  {formatCurrency(subtotal, currency, storeSettings.exchangeRate)}
                </span>
              </div>
              
              <div className="flex justify-between text-emerald-700 font-semibold">
                <span>Descuento ({discountPercent}%):</span>
                <span>-{formatCurrency(discountAmount, currency, storeSettings.exchangeRate)}</span>
              </div>

              <div className="flex justify-between text-stone-600">
                <span>Envío:</span>
                <span className={isFreeShipping ? 'text-emerald-700 font-bold' : 'font-semibold text-stone-800'}>
                  {isFreeShipping ? 'GRATIS' : formatCurrency(shipping, currency, storeSettings.exchangeRate)}
                </span>
              </div>

              <div className="flex justify-between text-base font-extrabold text-stone-950 pt-2 border-t border-stone-200">
                <span className="text-violet-900">TOTAL:</span>
                <div className="text-right">
                  <span className="text-violet-900 font-black">
                    {formatCurrency(total, currency, storeSettings.exchangeRate)}
                  </span>
                  {currency === 'dolares' && (
                    <div className="text-[10px] text-stone-500 font-normal">
                      ≈ C$ {total.toFixed(2)}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* 💳 Datos de Pago & Transferencia Bancaria */}
            {storeSettings.bankAccount && (
              <div className="p-3 bg-sky-50 border border-sky-200 rounded-xl space-y-1.5 text-xs text-sky-950">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-black text-sky-900">
                    <span>💳</span>
                    <span>Transferencia Bancaria</span>
                  </div>
                  <span className="text-[10px] font-bold bg-sky-200 text-sky-800 px-2 py-0.5 rounded-full">
                    Pago Directo
                  </span>
                </div>
                <div className="flex items-baseline justify-between pt-0.5">
                  <span className="text-[11px] text-sky-800">Número de Cuenta:</span>
                  <span className="font-mono font-black text-sm text-sky-950 bg-white px-2 py-0.5 rounded border border-sky-200">
                    {storeSettings.bankAccount}
                  </span>
                </div>
                {storeSettings.bankAccountHolder && (
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-sky-800">Titular:</span>
                    <span className="font-bold text-sky-900">{storeSettings.bankAccountHolder}</span>
                  </div>
                )}
                <div className="text-[10px] text-sky-700 flex items-center gap-1 pt-1 border-t border-sky-200/60">
                  <span>🛵</span>
                  <span>Coordinamos la entrega Delivery o retiro una vez confirmado tu pedido por WhatsApp.</span>
                </div>
              </div>
            )}

            {/* 📱 Main WhatsApp Checkout Button */}
            <button
              id="btn-checkout-whatsapp"
              onClick={handleCheckoutWhatsApp}
              className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 active:scale-98 text-white font-black text-sm sm:text-base shadow-lg hover:shadow-xl flex items-center justify-center gap-2.5 transition-all duration-200 cursor-pointer"
            >
              <MessageCircle className="w-5 h-5 fill-white/20 shrink-0" />
              <span>Realizar pedido por WhatsApp</span>
              <ArrowRight className="w-4 h-4 ml-auto shrink-0" />
            </button>

            <p className="text-[10px] text-center text-stone-400">
              💬 Al presionar se abrirá el WhatsApp oficial de <strong className="text-stone-600 font-bold">{storeSettings.storeName}</strong> ({storeSettings.whatsappNumber}) con tu lista de productos.
            </p>
          </div>
        )}
      </>
    )}

  </div>
</div>
);
};
