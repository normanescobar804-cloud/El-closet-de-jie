import React, { useState, useEffect } from 'react';
import { X, Heart, Plus, Minus, ShoppingBag, MessageCircle, Check, ShieldCheck, Truck, Star, ThumbsUp, Send } from 'lucide-react';
import { CurrencyType, Product, ProductReview, StoreSettings, UserAccount } from '../types';
import { formatCurrency, getProductReviews, getProductRatingStats, saveReview } from '../utils/storage';

interface ProductDetailModalProps {
  product: Product | null;
  currency: CurrencyType;
  storeSettings: StoreSettings;
  isFavorite: boolean;
  currentUser?: UserAccount | null;
  onClose: () => void;
  onAddToCart: (product: Product, size?: string, color?: string, quantity?: number) => void;
  onToggleFavorite: (product: Product) => void;
  onReviewAdded?: (newReview: ProductReview) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  currency,
  storeSettings,
  isFavorite,
  currentUser,
  onClose,
  onAddToCart,
  onToggleFavorite,
  onReviewAdded,
}) => {
  if (!product) return null;

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes?.[0] || 'Única');
  const [selectedColor, setSelectedColor] = useState<string>(product.colors?.[0] || 'Original');
  const [quantity, setQuantity] = useState(1);
  const [addedAnimation, setAddedAnimation] = useState(false);

  // ⭐ 5-Star Reviews & Rating State
  const [reviews, setReviews] = useState<ProductReview[]>([]);
  const [showRatingForm, setShowRatingForm] = useState(false);
  const [selectedStars, setSelectedStars] = useState<number>(5);
  const [hoverStars, setHoverStars] = useState<number>(0);
  const [reviewerName, setReviewerName] = useState(currentUser?.name || '');
  const [reviewerComment, setReviewerComment] = useState('');
  const [reviewSubmittedSuccess, setReviewSubmittedSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'reviews'>('details');

  useEffect(() => {
    if (product) {
      setReviews(getProductReviews(product.id));
      setSelectedImageIndex(0);
      setSelectedSize(product.sizes?.[0] || 'Única');
      setSelectedColor(product.colors?.[0] || 'Original');
      setQuantity(1);
      setShowRatingForm(false);
      setReviewSubmittedSuccess(false);
      setReviewerName(currentUser?.name || '');
      setReviewerComment('');
      setActiveTab('details');
    }
  }, [product?.id, currentUser?.name]);

  const ratingStats = product ? getProductRatingStats(product.id, reviews) : { average: 5.0, count: 0, breakdown: {} };

  const handleRatingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!product) return;

    const newReview: ProductReview = {
      id: `rev-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      productId: product.id,
      customerName: reviewerName.trim() || 'Cliente Satisfecho',
      rating: selectedStars,
      comment: reviewerComment.trim() || '¡Excelente prenda, muy recomendada!',
      verifiedPurchase: true,
      createdAt: new Date().toLocaleDateString('es-NI', { year: 'numeric', month: 'short', day: 'numeric' })
    };

    saveReview(newReview);
    const updated = [newReview, ...reviews];
    setReviews(updated);
    setReviewSubmittedSuccess(true);
    setShowRatingForm(false);
    setReviewerComment('');
    if (onReviewAdded) onReviewAdded(newReview);

    setTimeout(() => {
      setReviewSubmittedSuccess(false);
    }, 4000);
  };

  const images = product.images && product.images.length > 0
    ? product.images
    : ['https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80'];

  const discountPercent = product.originalPrice && product.originalPrice > product.price
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 20;

  const itemTotal = product.price * quantity;

  const handleAddToCart = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
    setAddedAnimation(true);
    setTimeout(() => {
      setAddedAnimation(false);
      onClose();
    }, 500);
  };

  const handleDirectWhatsAppInquiry = () => {
    let rawNumber = storeSettings.whatsappNumber.replace(/\D/g, '');
    if (rawNumber.length === 8) {
      rawNumber = `505${rawNumber}`;
    }
    if (!rawNumber) rawNumber = '50583702337';

    const text = encodeURIComponent(
      `¡Hola ${storeSettings.storeName}! ✨ Me interesa esta prenda:\n\n` +
      `👗 Prenda: ${product.name} ${product.icon || ''}\n` +
      `📏 Talla: ${selectedSize}\n` +
      `🎨 Color: ${selectedColor}\n` +
      `🔢 Cantidad: ${quantity}\n` +
      `💰 Precio: ${formatCurrency(itemTotal, currency, storeSettings.exchangeRate)}\n\n` +
      `¿Tienen disponible para entrega? ¡Muchas gracias!`
    );
    window.open(`https://wa.me/${rawNumber}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div
        className="relative bg-white w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl border border-stone-200 flex flex-col md:flex-row max-h-[92vh] md:max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          id="btn-close-product-modal"
          onClick={onClose}
          className="absolute top-3 right-3 z-20 w-9 h-9 bg-white/90 hover:bg-white text-stone-700 hover:text-stone-950 rounded-full flex items-center justify-center shadow-md backdrop-blur-xs transition-transform active:scale-95 cursor-pointer"
          title="Cerrar ventana"
          aria-label="Cerrar"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Gallery / Photos Left Section */}
        <div className="w-full md:w-1/2 bg-stone-50 flex flex-col justify-between p-4 sm:p-6">
          {/* Main High-Res Image Display */}
          <div className="relative aspect-square sm:aspect-[4/5] w-full rounded-2xl overflow-hidden bg-white shadow-inner flex items-center justify-center border border-stone-200">
            <img
              src={images[selectedImageIndex]}
              alt={`${product.name} - Vista ${selectedImageIndex + 1}`}
              className="w-full h-full object-cover object-center transition-all duration-300"
            />

            {/* Badges */}
            <div className="absolute top-3 left-3 flex flex-col gap-1.5 pointer-events-none">
              <span className="bg-rose-600 text-white text-xs font-black px-2.5 py-1 rounded-full shadow-xs">
                -{discountPercent}% OFF
              </span>
              {product.condition === 'usada' ? (
                <span className="bg-amber-500 text-stone-950 text-xs font-black px-2.5 py-1 rounded-full shadow-xs uppercase tracking-wider flex items-center gap-1">
                  <span>♻️</span> Ropa Usada
                </span>
              ) : (
                <span className="bg-emerald-600 text-white text-xs font-black px-2.5 py-1 rounded-full shadow-xs uppercase tracking-wider flex items-center gap-1">
                  <span>✨</span> Ropa Nueva
                </span>
              )}
            </div>

            {/* Product Emoji Tag */}
            {product.icon && (
              <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-xs rounded-xl px-2.5 py-1 text-2xl shadow-sm">
                {product.icon}
              </div>
            )}

            {/* Heart Favorite in Modal */}
            <button
              onClick={() => onToggleFavorite(product)}
              className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-stone-700 hover:text-rose-600 shadow-sm flex items-center justify-center cursor-pointer"
              title="Favorito"
              aria-label="Favorito"
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
            </button>
          </div>

          {/* Thumbnail Gallery */}
          {images.length > 1 && (
            <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`w-14 h-14 rounded-lg overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                    selectedImageIndex === idx
                      ? 'border-violet-600 ring-2 ring-violet-200 scale-105'
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="Miniatura" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Details Right Section */}
        <div className="w-full md:w-1/2 p-5 sm:p-7 overflow-y-auto flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[11px] uppercase tracking-widest font-bold text-violet-700">
                  {product.category}
                </span>
                <span className="text-stone-300">•</span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                  product.condition === 'usada'
                    ? 'bg-amber-100 text-amber-900 border border-amber-200'
                    : 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                }`}>
                  {product.condition === 'usada' ? '♻️ Prenda Usada' : '✨ Prenda Nueva'}
                </span>
              </div>
              <h2 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 leading-tight">
                {product.name}
              </h2>
            </div>

            {/* ⭐ Calificación 5 Estrellas Bar */}
            <div className="flex items-center justify-between py-2 px-3 bg-amber-50/70 border border-amber-200/80 rounded-xl">
              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-4 h-4 ${
                        star <= Math.round(ratingStats.average)
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-stone-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-xs font-black text-amber-950">
                  {ratingStats.average.toFixed(1)} de 5
                </span>
                <span className="text-[11px] text-amber-800">
                  ({reviews.length} {reviews.length === 1 ? 'opinión' : 'opiniones'})
                </span>
              </div>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('reviews');
                  setShowRatingForm(true);
                }}
                className="text-xs font-bold text-amber-900 hover:text-amber-950 bg-amber-200/70 hover:bg-amber-200 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
              >
                <span>⭐ Calificar</span>
              </button>
            </div>

            {/* Tabs Selector: Prenda vs Opiniones */}
            <div className="flex border-b border-stone-200 gap-4 text-xs font-bold">
              <button
                type="button"
                onClick={() => setActiveTab('details')}
                className={`pb-2 transition-colors cursor-pointer ${
                  activeTab === 'details'
                    ? 'text-violet-700 border-b-2 border-violet-700'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                Detalles y Tallas
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('reviews')}
                className={`pb-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'reviews'
                    ? 'text-violet-700 border-b-2 border-violet-700'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                <span>⭐ Opiniones ({reviews.length})</span>
              </button>
            </div>

            {activeTab === 'details' ? (
              <div className="space-y-4">
                {/* Price Row */}
                <div className="flex items-baseline gap-3 pb-2 border-b border-stone-100">
                  <span className="text-2xl sm:text-3xl font-black text-stone-900">
                    {formatCurrency(product.price, currency, storeSettings.exchangeRate)}
                  </span>
                  {product.originalPrice && product.originalPrice > product.price && (
                    <span className="text-sm text-stone-400 line-through">
                      {formatCurrency(product.originalPrice, currency, storeSettings.exchangeRate)}
                    </span>
                  )}
                  {currency === 'dolares' && (
                    <span className="text-xs text-stone-500">
                      (C$ {product.price.toFixed(2)})
                    </span>
                  )}
                </div>

                {/* Description */}
                <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                  {product.description || 'Prenda de alta calidad para toda la familia en El closet de jie.'}
                </p>

                {/* Size Selector */}
                {product.sizes && product.sizes.length > 0 && (
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1.5">
                      Talla: <span className="text-violet-900 font-extrabold">{selectedSize}</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {product.sizes.map((sz) => (
                        <button
                          key={sz}
                          onClick={() => setSelectedSize(sz)}
                          className={`min-w-[40px] h-9 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            selectedSize === sz
                              ? 'bg-violet-700 text-white border-violet-700 shadow-xs'
                              : 'bg-stone-50 text-stone-700 border-stone-200 hover:border-stone-400'
                          }`}
                        >
                          {sz}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Color Selector */}
                {product.colors && product.colors.length > 0 && (
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1.5">
                      Color: <span className="text-violet-900 font-extrabold">{selectedColor}</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {product.colors.map((color) => (
                        <button
                          key={color}
                          onClick={() => setSelectedColor(color)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                            selectedColor === color
                              ? 'bg-violet-50 text-violet-900 border-violet-400 font-bold'
                              : 'bg-white text-stone-600 border-stone-200 hover:border-stone-300'
                          }`}
                        >
                          {color}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quantity Selector */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1.5">
                    Cantidad a pedir
                  </label>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center border border-stone-300 rounded-xl bg-stone-50 overflow-hidden shadow-2xs">
                      <button
                        id="btn-qty-minus"
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        disabled={quantity <= 1}
                        className="w-8 h-8 flex items-center justify-center text-stone-700 hover:bg-stone-200 disabled:opacity-40 transition-colors cursor-pointer"
                        aria-label="Menos"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-10 text-center font-black text-sm text-stone-900">
                        {quantity}
                      </span>
                      <button
                        id="btn-qty-plus"
                        onClick={() => setQuantity(quantity + 1)}
                        className="w-8 h-8 flex items-center justify-center text-stone-700 hover:bg-stone-200 transition-colors cursor-pointer"
                        aria-label="Más"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="text-xs text-stone-500">
                      Subtotal: <span className="font-bold text-stone-900">{formatCurrency(itemTotal, currency, storeSettings.exchangeRate)}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* ⭐ Reviews and 5-Star Ratings Section */
              <div className="space-y-4">
                {reviewSubmittedSuccess && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>¡Muchas gracias! Tu calificación de {selectedStars} estrellas se guardó correctamente.</span>
                  </div>
                )}

                {/* Top Rating Summary Card */}
                <div className="p-4 bg-stone-50 border border-stone-200 rounded-2xl flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-black text-stone-900">
                        {ratingStats.average.toFixed(1)}
                      </span>
                      <span className="text-xs text-stone-500">de 5.0</span>
                    </div>
                    <div className="flex items-center">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star
                          key={s}
                          className={`w-3.5 h-3.5 ${
                            s <= Math.round(ratingStats.average)
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-stone-300'
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-[11px] text-stone-500">
                      Basado en {reviews.length} {reviews.length === 1 ? 'cliente' : 'clientes'}
                    </p>
                  </div>

                  {!showRatingForm && (
                    <button
                      type="button"
                      onClick={() => setShowRatingForm(true)}
                      className="px-3 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                    >
                      <span>★ Calificar prenda</span>
                    </button>
                  )}
                </div>

                {/* Interactive Rating Form */}
                {showRatingForm && (
                  <form onSubmit={handleRatingSubmit} className="p-4 bg-violet-50/70 border border-violet-200 rounded-2xl space-y-3 animate-fade-in">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-violet-950 uppercase tracking-wider">
                        ¿Cuántas estrellas le das a esta prenda?
                      </h4>
                      <button
                        type="button"
                        onClick={() => setShowRatingForm(false)}
                        className="text-xs text-stone-400 hover:text-stone-600"
                      >
                        Cancelar
                      </button>
                    </div>

                    {/* 5 Stars Interactive Selector */}
                    <div className="flex flex-col gap-1 items-start">
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setSelectedStars(star)}
                            onMouseEnter={() => setHoverStars(star)}
                            onMouseLeave={() => setHoverStars(0)}
                            className="p-1 transition-transform hover:scale-125 active:scale-95 cursor-pointer"
                            aria-label={`${star} estrellas`}
                          >
                            <Star
                              className={`w-7 h-7 transition-colors ${
                                star <= (hoverStars || selectedStars)
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-stone-300'
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                      <span className="text-xs font-bold text-amber-900">
                        {selectedStars === 5 && '⭐⭐⭐⭐⭐ ¡Excelente! Me encantó la prenda'}
                        {selectedStars === 4 && '⭐⭐⭐⭐ ¡Muy buena! Buena calidad y tela'}
                        {selectedStars === 3 && '⭐⭐⭐ Buena / Aceptable'}
                        {selectedStars === 2 && '⭐⭐ Regular'}
                        {selectedStars === 1 && '⭐ No me gustó'}
                      </span>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-stone-700 mb-1">
                        Tu Nombre
                      </label>
                      <input
                        type="text"
                        value={reviewerName}
                        onChange={(e) => setReviewerName(e.target.value)}
                        placeholder="Ej: Sofia Morales"
                        className="w-full px-3 py-2 bg-white border border-violet-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-violet-400"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-stone-700 mb-1">
                        Tu Opinión sobre la prenda o el servicio (Opcional)
                      </label>
                      <textarea
                        rows={2}
                        value={reviewerComment}
                        onChange={(e) => setReviewerComment(e.target.value)}
                        placeholder="Ej: La tela es fresca, la talla perfecta y el envío en Managua fue súper rápido..."
                        className="w-full px-3 py-2 bg-white border border-violet-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-violet-400"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-violet-700 hover:bg-violet-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-colors"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Publicar mi Calificación de {selectedStars} Estrellas</span>
                    </button>
                  </form>
                )}

                {/* Customer Reviews List */}
                <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                  {reviews.length === 0 ? (
                    <div className="text-center py-6 text-stone-400 text-xs">
                      Aún no hay opiniones escritas. ¡Sé la primera persona en darle 5 estrellas a esta prenda!
                    </div>
                  ) : (
                    reviews.map((rev) => (
                      <div key={rev.id} className="p-3 bg-stone-50 border border-stone-200/80 rounded-xl space-y-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-stone-900">{rev.customerName}</span>
                            {rev.verifiedPurchase && (
                              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200 flex items-center gap-0.5">
                                <Check className="w-2.5 h-2.5" /> Compra Verificada
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-stone-400">{rev.createdAt}</span>
                        </div>

                        {/* Stars */}
                        <div className="flex items-center">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`w-3 h-3 ${
                                s <= rev.rating
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-stone-300'
                              }`}
                            />
                          ))}
                        </div>

                        {rev.comment && (
                          <p className="text-stone-600 text-[11px] leading-relaxed">
                            {rev.comment}
                          </p>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="pt-5 mt-5 border-t border-stone-100 space-y-2.5">
            <button
              id="btn-confirm-add-cart"
              onClick={handleAddToCart}
              disabled={!product.inStock}
              className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all duration-200 shadow-md cursor-pointer ${
                product.inStock
                  ? addedAnimation
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white active:scale-98'
                  : 'bg-stone-200 text-stone-400 cursor-not-allowed'
              }`}
            >
              {addedAnimation ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>¡Agregado al Carrito!</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-4 h-4" />
                  <span>Agregar al Carrito • {formatCurrency(itemTotal, currency, storeSettings.exchangeRate)}</span>
                </>
              )}
            </button>

            {/* Direct WhatsApp button */}
            <button
              id="btn-direct-whatsapp-item"
              onClick={handleDirectWhatsAppInquiry}
              className="w-full py-2.5 px-4 rounded-xl font-bold text-xs text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 flex items-center justify-center gap-2 transition-colors active:scale-98 cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              <span>Consultar por WhatsApp ({storeSettings.whatsappNumber})</span>
            </button>

            {/* Trust badges */}
            <div className="grid grid-cols-2 gap-2 pt-2 text-[10px] text-stone-500">
              <div className="flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-stone-400" />
                <span>Envíos a toda Nicaragua</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-stone-400" />
                <span>Descuento del 20% aplicado</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
