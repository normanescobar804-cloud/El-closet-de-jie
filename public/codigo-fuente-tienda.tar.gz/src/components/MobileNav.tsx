import React from 'react';
import { Home, Heart, ShoppingBag, User, MessageCircle } from 'lucide-react';
import { CurrencyType, StoreSettings, UserAccount } from '../types';
import { formatCurrency } from '../utils/storage';

interface MobileNavProps {
  activeTab: 'catalog' | 'favorites' | 'cart' | 'admin';
  cartCount: number;
  cartTotal: number;
  currency: CurrencyType;
  storeSettings: StoreSettings;
  favoritesCount: number;
  currentUser: UserAccount | null;
  onOpenCatalog: () => void;
  onOpenFavorites: () => void;
  onOpenCart: () => void;
  onOpenAuth: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeTab,
  cartCount,
  cartTotal,
  currency,
  storeSettings,
  favoritesCount,
  currentUser,
  onOpenCatalog,
  onOpenFavorites,
  onOpenCart,
  onOpenAuth,
}) => {
  const handleOpenWhatsAppDirect = () => {
    let rawNumber = storeSettings.whatsappNumber.replace(/\D/g, '');
    if (rawNumber.length === 8) {
      rawNumber = `505${rawNumber}`;
    }
    if (!rawNumber) rawNumber = '50583702337';
    const text = encodeURIComponent(`¡Hola ${storeSettings.storeName}! 👋 Quisiera información sobre sus prendas y envíos.`);
    window.open(`https://wa.me/${rawNumber}?text=${text}`, '_blank');
  };

  return (
    <>
      {/* Floating Cart Bar when items are in cart (Mobile only) */}
      {cartCount > 0 && activeTab !== 'cart' && (
        <div className="md:hidden fixed bottom-18 left-3 right-3 z-40 animate-slide-up">
          <button
            onClick={onOpenCart}
            className="w-full bg-gradient-to-r from-violet-700 via-purple-700 to-indigo-800 text-white p-3 rounded-2xl shadow-xl flex items-center justify-between border border-violet-500/30 active:scale-98 transition-all"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-bold text-xs">
                {cartCount}
              </div>
              <div className="text-left">
                <div className="text-xs font-black">Ver mi Carrito</div>
                <div className="text-[10px] text-violet-200">
                  {cartCount} producto{cartCount !== 1 ? 's' : ''} listo{cartCount !== 1 ? 's' : ''} para ordenar
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-black bg-white/15 px-2.5 py-1 rounded-lg">
                {formatCurrency(cartTotal, currency, storeSettings.exchangeRate)}
              </span>
              <span className="text-xs font-bold text-amber-300">Ordenar →</span>
            </div>
          </button>
        </div>
      )}

      {/* Bottom Navigation Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-stone-200/90 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] pb-safe">
        <nav className="grid grid-cols-5 h-16 max-w-md mx-auto px-1 items-center">
          
          {/* Catálogo / Inicio */}
          <button
            id="mobile-nav-catalog"
            onClick={onOpenCatalog}
            className={`flex flex-col items-center justify-center gap-0.5 h-full ${
              activeTab === 'catalog' ? 'text-violet-700 font-bold' : 'text-stone-600'
            } active:scale-95 transition-all`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] tracking-tight">Tienda</span>
          </button>

          {/* Favoritos */}
          <button
            id="mobile-nav-favorites"
            onClick={onOpenFavorites}
            className={`relative flex flex-col items-center justify-center gap-0.5 h-full ${
              activeTab === 'favorites' ? 'text-rose-600 font-bold' : 'text-stone-600'
            } active:scale-95 transition-all`}
          >
            <div className="relative">
              <Heart className={`w-5 h-5 ${favoritesCount > 0 ? 'fill-rose-500 text-rose-500' : ''}`} />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-2 bg-rose-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                  {favoritesCount}
                </span>
              )}
            </div>
            <span className="text-[10px] tracking-tight">Deseos</span>
          </button>

          {/* Carrito de Compras (Central destacado) */}
          <button
            id="mobile-nav-cart"
            onClick={onOpenCart}
            className="relative flex flex-col items-center justify-center gap-0.5 active:scale-95 transition-all -top-1.5"
          >
            <div className="relative w-12 h-12 bg-gradient-to-tr from-violet-600 to-indigo-600 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-white">
              <ShoppingBag className="w-5 h-5 text-amber-200" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-xs animate-pulse">
                  {cartCount}
                </span>
              )}
            </div>
            <span className="text-[10px] font-bold text-stone-900 tracking-tight">Carrito</span>
          </button>

          {/* WhatsApp Directo */}
          <button
            id="mobile-nav-whatsapp"
            onClick={handleOpenWhatsAppDirect}
            className="flex flex-col items-center justify-center gap-0.5 h-full text-emerald-700 active:scale-95 transition-all"
            title="Chat en WhatsApp"
          >
            <MessageCircle className="w-5 h-5 fill-emerald-100" />
            <span className="text-[10px] tracking-tight font-medium">WhatsApp</span>
          </button>

          {/* Perfil / Login rápido */}
          <button
            id="mobile-nav-user"
            onClick={onOpenAuth}
            className="flex flex-col items-center justify-center gap-0.5 h-full text-stone-600 active:scale-95 transition-all"
          >
            <div className="relative">
              <User className="w-5 h-5" />
              {currentUser?.isLoggedIn && (
                <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-emerald-500 rounded-full border border-white"></span>
              )}
            </div>
            <span className="text-[10px] tracking-tight">
              {currentUser?.isLoggedIn ? 'Perfil' : 'Ingresar'}
            </span>
          </button>

        </nav>
      </div>
    </>
  );
};
