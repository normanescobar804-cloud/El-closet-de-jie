import React, { useState, useId } from 'react';
import { X, User, Heart, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';
import { UserAccount } from '../types';

interface QuickAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount | null;
  onLogin: (user: UserAccount) => void;
  onLogout: () => void;
}

export const QuickAuthModal: React.FC<QuickAuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLogin,
  onLogout,
}) => {
  const nameInputId = useId();
  const contactInputId = useId();
  const cityInputId = useId();

  const [name, setName] = useState(currentUser?.name || '');
  const [phoneOrEmail, setPhoneOrEmail] = useState(currentUser?.phoneOrEmail || '');
  const [city, setCity] = useState(currentUser?.city || '');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Por favor escribe tu nombre');
      return;
    }
    if (!phoneOrEmail.trim()) {
      setError('Por favor ingresa tu WhatsApp o Correo');
      return;
    }

    const newUser: UserAccount = {
      name: name.trim(),
      phoneOrEmail: phoneOrEmail.trim(),
      city: city.trim(),
      isLoggedIn: true,
      loginDate: new Date().toISOString()
    };

    onLogin(newUser);
    onClose();
  };

  const handleQuickDemoLogin = (demoName: string) => {
    const demoUser: UserAccount = {
      name: demoName,
      phoneOrEmail: '3109876543',
      city: 'Bogotá',
      isLoggedIn: true,
      loginDate: new Date().toISOString()
    };
    onLogin(demoUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div
        className="relative bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-stone-200 p-6 sm:p-7"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="btn-close-quick-auth"
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-500 hover:text-stone-900 flex items-center justify-center transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {currentUser?.isLoggedIn ? (
          /* User Profile View */
          <div className="space-y-5 text-center">
            <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center text-2xl font-bold mx-auto">
              {currentUser.name.charAt(0).toUpperCase()}
            </div>

            <div>
              <h3 className="font-serif text-xl font-bold text-stone-900">
                ¡Hola, {currentUser.name}!
              </h3>
              <p className="text-xs text-stone-500 mt-1">
                {currentUser.phoneOrEmail} {currentUser.city ? `• ${currentUser.city}` : ''}
              </p>
            </div>

            <div className="bg-stone-50 rounded-2xl p-4 text-xs text-stone-600 text-left space-y-2 border border-stone-100">
              <div className="flex items-center gap-2 text-rose-800 font-semibold">
                <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
                <span>Tus favoritos están sincronizados y guardados</span>
              </div>
              <p className="text-stone-500">
                Puedes explorar la colección en cualquier momento y tus prendas marcadas estarán listas para ti.
              </p>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                id="btn-logout-account"
                onClick={() => {
                  onLogout();
                  onClose();
                }}
                className="flex-1 py-2.5 px-4 rounded-xl border border-stone-200 text-xs font-semibold text-stone-600 hover:text-red-600 hover:border-red-200 transition-colors"
              >
                Cerrar Sesión
              </button>
              <button
                id="btn-continue-shopping"
                onClick={onClose}
                className="flex-1 py-2.5 px-4 rounded-xl bg-stone-900 text-white text-xs font-semibold hover:bg-stone-800 transition-colors"
              >
                Seguir Comprando
              </button>
            </div>
          </div>
        ) : (
          /* Quick Login Form */
          <div>
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-700 flex items-center justify-center mx-auto mb-3">
                <Heart className="w-6 h-6 fill-rose-100 text-rose-600" />
              </div>
              <h3 className="font-serif text-xl font-bold text-stone-900">
                Inicio de Sesión Rápido
              </h3>
              <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
                Ingresa tus datos para guardar tus prendas favoritas y agilizar tus pedidos por WhatsApp.
              </p>
            </div>

            {error && (
              <div className="mb-4 text-xs text-red-600 bg-red-50 p-2.5 rounded-xl border border-red-200 font-medium">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label htmlFor={nameInputId} className="block text-xs font-semibold text-stone-700 mb-1">
                  Tu Nombre y Apellido
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id={nameInputId}
                    type="text"
                    required
                    placeholder="Ej: Carolina Rojas"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label htmlFor={contactInputId} className="block text-xs font-semibold text-stone-700 mb-1">
                  WhatsApp o Correo Electrónico
                </label>
                <input
                  id={contactInputId}
                  type="text"
                  required
                  placeholder="Ej: 310 555 7890 o tu@correo.com"
                  value={phoneOrEmail}
                  onChange={(e) => setPhoneOrEmail(e.target.value)}
                  className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                />
              </div>

              <div>
                <label htmlFor={cityInputId} className="block text-xs font-semibold text-stone-700 mb-1">
                  Ciudad (Opcional)
                </label>
                <input
                  id={cityInputId}
                  type="text"
                  placeholder="Ej: Bogotá, Medellín, Cali..."
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                />
              </div>

              <button
                type="submit"
                id="btn-submit-quick-login"
                className="w-full py-3 px-4 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-all shadow-xs"
              >
                <span>Guardar y Continuar</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* Quick 1-click test button */}
            <div className="mt-5 pt-4 border-t border-stone-100 text-center">
              <span className="text-[11px] text-stone-400 block mb-2">O prueba con 1 toque:</span>
              <button
                type="button"
                id="btn-fast-guest-login"
                onClick={() => handleQuickDemoLogin('Cliente Especial')}
                className="w-full py-2 px-3 rounded-lg border border-dashed border-stone-300 text-stone-600 hover:bg-stone-50 text-[11px] font-medium flex items-center justify-center gap-1.5 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Entrar como Invitado Rápido</span>
              </button>
            </div>

            <div className="mt-4 flex items-center justify-center gap-1 text-[10px] text-stone-400">
              <ShieldCheck className="w-3.5 h-3.5 text-stone-400" />
              <span>Tus datos se guardan de forma segura en tu navegador</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
